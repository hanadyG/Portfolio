import axios from "axios";

const url = "http://localhost:8081"

class AuthService {
    login(uname, pass) {
        return axios
            .post(url + "/auth", {}, {
                auth: {
                    username: uname,
                    password: pass
                }
            });
    }

    logout() {
        axios.get(url + "/auth/logout")
    }

    /* register(username, email, password) {
        return axios.post(API_URL + "signup", {
            username,
            email,
            password
        });
    } */

    getCurrentUser() {
        return JSON.parse(localStorage.getItem('user'));
    }

    isauthenticated() {
        axios.get(process.env.REACT_APP_PUBLIC_URL + "/auth").then(response => {
            return response.data;
        })
    }


}

export default new AuthService();
