import React from 'react';
import logo from './logo.svg';
import { Counter } from './features/counter/Counter';
import './App.css';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import Delivery from "./pages/dispatcher/Delivery";
import Customer from "./pages/dispatcher/Customer";
import Deliverer from "./pages/dispatcher/Deliverer";
import PickupBox from "./pages/dispatcher/PickupBox";
import Dispatcher from "./pages/dispatcher/Dispatcher";
import CustomerPage from "./pages/customer/CustomerPage";
import DelivererPage from "./pages/deliverer/DelivererPage";
import Login from "./pages/Login/Login";
import axios from 'axios';
function App() {
  const [value, setValue] = React.useState(0);
  axios.defaults.withCredentials = true;

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <Router>
      <Tabs value={value} onChange={handleChange}>
        <Tab label='Home' to='/' component={Link} />
        <Tab label='Deliveries' to='/dispatcher/deliveries' component={Link} />
        <Tab label='Customers' to='/dispatcher/customers' component={Link} />
        <Tab label='Deliverers' to='/dispatcher/deliverers' component={Link} />
        <Tab label='PickupBoxes' to='/dispatcher/pickupboxes' component={Link} />
        <Tab label='Dispatchers' to='/dispatcher/dispatchers' component={Link} />
        <Tab label='Customer Page' to='/customer/customer_page' component={Link} />
        <Tab label='Deliverer Page' to='/deliverer/deliverer_page' component={Link} />
        <Tab label='Login' to='/login' component={Link} />
      </Tabs>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/dispatcher/deliveries" element={<Delivery />} />
        <Route path="/dispatcher/customers" element={<Customer />} />
        <Route path="/dispatcher/deliverers" element={<Deliverer />} />
        <Route path="/dispatcher/pickupboxes" element={<PickupBox />} />
        <Route path="/dispatcher/dispatchers" element={<Dispatcher />} />
        <Route path="/customer/customer_page" element={<CustomerPage />} />
        <Route path="/deliverer/deliverer_page" element={<DelivererPage />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </Router>
  );
}

export default App;
