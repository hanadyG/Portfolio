import React, { useState, useEffect } from 'react'
import { DataGrid, getDataGridUtilityClass } from '@mui/x-data-grid';
import Button from '@mui/material/Button';
import axios from 'axios'
import { TextField } from '@mui/material';
import Box from '@mui/material/Box';
import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import MenuItem from '@mui/material/MenuItem';
import { textAlign } from '@mui/system';
import Checkbox from '@mui/material/Checkbox';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';



function CustomerPage() {
    const columns = [
      { field: 'id', headerName: 'ID', width: 120 },
      { field: 'status', headerName: 'Status', width: 200  },
      { field: 'trackingCode', headerName:"Tracking Code", width: 250},
      { field: 'assigned_deliverer', headerName:"Assigned Deliverer", width: 250},
      { field: 'assigned_pickupbox_name', headerNAme: "Assigned PickupBox Name", width: 250},
      { field: 'assigned_pickupbox_address', headerName:"Assigned PickupBox Address", width: 250}
    ];

    const [customer, setCustomer] = useState({})
    const [customerID, setCustomerID] = useState('')
    const [trackingCode, setTrackingCode] = useState('')
    const [searchResult, setSearchResult] = useState({})
    const [displayedRows, setDisplayedRows] = useState({})

    const getData = () => {
        axios
            .get(process.env.REACT_APP_PUBLIC_URL + '/customer/deliveries/' + customerID)
            .then(res => {
              
              let arr = []
              if(Array.isArray(res.data)) {
                res.data.forEach(item =>
                                        {
                                            if(item != null && item != undefined){
                                                arr.push({
                                                    id: item.id,
                                                    status: item.status,
                                                    trackingCode: item.trackingCode,
                                                    assigned_deliverer: item.deliverer.email,
                                                    assigned_pickupbox_address: item.pickupBox.address,
                                                    assigned_pickupbox_name: item.pickupBox.name
                                                  })
                                            }
                                        }    
                                  )
                                        
                }
                setCustomer(arr);
                setDisplayedRows(arr)
              })
            
    }

    const getTrackingCodeDelivery = () => {
        var result = customer.filter(obj => {
            return obj.trackingCode === trackingCode
          })
        setSearchResult(result)
        setDisplayedRows(result)
    }

    const handleClear = () => {
        setTrackingCode("")
        setDisplayedRows(customer)
    }

    const handleCustomerIDChange = (event) => {
        console.log(event.target.value);
        setCustomerID(event.target.value);
    };

    const handleTrackingCodeChange = (event) => {
        console.log(event.target.value);
        setTrackingCode(event.target.value);
        console.log(event.target.value)
        if(event.target.value == "")
        {
            setDisplayedRows(customer);
        }
    };

    useEffect(() => {
        getData()
      }, 
      []
    )
    return (
    <div>
        <Box
          component="form"
          sx={{
            '& .MuiTextField-root': { m: 1, width: '40ch' },
          }}
          noValidate
          autoComplete="off"
        >
          <div>
            <TextField
              required
              id="filled-required"
              label="Customer ID"
              defaultValue=""
              variant="filled"
              value={customerID}
              onChange={e => handleCustomerIDChange(e)}
            />
            <br></br>
            <Button variant="outlined" color="success" onClick={() => getData()}>Get Customer's Deliveries</Button>
          </div>

          <div>
            <TextField
              id="filled-required"
              label="Tracking Code"
              defaultValue=""
              variant="filled"
              value={trackingCode}
              onChange={e => handleTrackingCodeChange(e)}
            />
            {
                trackingCode ? 
                (
                    <Button variant="outlined" color="error" onClick={handleClear} >
                        X
                    </Button>
                ) :
                (
                    <span></span>
                )
            }
            
            <br></br>
            <Button variant="outlined" color="success" onClick={() => getTrackingCodeDelivery()}>Search by Tracking Code</Button>
          </div>

         </Box>
      <div style={{ height: 370, width: '100%' }}>
        <DataGrid
          rows={displayedRows}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5]}
        />
      </div>
      <br></br>
      <br></br>
    
    </div>
    );
}

export default CustomerPage;