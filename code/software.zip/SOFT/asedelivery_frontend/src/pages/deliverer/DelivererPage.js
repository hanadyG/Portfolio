import React, { useState, useEffect } from 'react'
import { DataGrid, getDataGridUtilityClass } from '@mui/x-data-grid';
import Button from '@mui/material/Button';
import axios from 'axios'
import { TextField } from '@mui/material';
import Box from '@mui/material/Box';
import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import MenuItem from '@mui/material/MenuItem';

const status_values = [
  {
    id: 1,
    value: 'ordered'
  },
  {
    id: 2,
    value: 'picked-up'
  },
  {
    id: 3,
    value: 'delivered'
  },
  {
    id: 4,
    value: 'collected'
  },
  {
    id: 5,
    value: 'cancelled'
  }
];

function DelivererPage() {
    const renderDetailsButton = (params) => {
      return (
          <strong>
              <Button name='Update'
                  variant="contained"
                  color="primary"
                  size="large"
                  style={{ marginLeft: 16, height: 30 }}
                  onClick={(e) => {
                    console.log(params.row.email)
                      setUpdatedStatus(params.row.status)
                      setUpdateSelectedID(params.id)
                      setUpdateSelectedTrackingCode(params.row.trackingCode)
                      setButtonName("Update the Customer")
                  }}
              >
                  Update
              </Button>
          </strong>
      )
    }
    const columns = [
      { field: 'id', headerName: 'ID', width: 200 },
      { field: 'status', headerName: 'Status', width: 200  },
      { field: 'trackingCode', headerName:"Tracking Code", width: 250},
      { field: 'assigned_customer', headerName:"Assigned Customer", width: 200},
      { field: 'assigned_pickupbox_name', headerNAme: "Assigned PickupBox Name", width: 250},
      { field: 'assigned_pickupbox_address', headerName:"Assigned PickupBox Address", width: 250},
      {
        field: 'col5',
        headerName: 'Update',
        width: 150,
        renderCell: renderDetailsButton,
        disableClickEventBubbling: true,
      }
    ];

    const [deliverer, setDeliverer] = useState({})
    const [buttonName, setButtonName] = useState("Create New Delivery")
    const [selectedRows, setSelectedRows] = useState({})
    const [id, setId] = useState(1)
    const [idFromButtonClick, setIdFromButtonClick] = useState(1)
    const [updateSelectedID, setUpdateSelectedID] = useState()

    const [delivererID, setDelivererID] = useState('')
    const [updatedStatus, setUpdatedStatus] = useState('')
    const [updateSelectedTrackingCode, setUpdateSelectedTrackingCode] = useState('')
    const getData = () => {
        axios
            .get(process.env.REACT_APP_PUBLIC_URL + '/deliverer/deliveries/' + delivererID)
            .then(res => {
              
              let arr = []
              if(Array.isArray(res.data)) {
                res.data.forEach(item =>
                                        {
                                          console.log(item)
                                            if(item != null && item != undefined && item.customer != null){
                                                arr.push({
                                                    id: item.id,
                                                    status: item.status,
                                                    trackingCode: item.trackingCode,
                                                    assigned_customer: item.customer.email,
                                                    assigned_pickupbox_address: item.pickupBox.address,
                                                    assigned_pickupbox_name: item.pickupBox.name
                                                  })
                                            }
                                        }    
                                  )
                                        
                }
                setDeliverer(arr);
              })
            
    }

    const handleUpdateDelivery = () => {

        var data = {
          "status": updatedStatus
        }
        console.log(data)
        axios
            .put(process.env.REACT_APP_PUBLIC_URL + '/deliverer/update_delivery/'+updateSelectedID, data)
            .then(res => {
              //console.log(res)
              getData()
              }).catch(error => {
                alert("Couldn't update the Delivery. Try again with confirmed inputs");
        });
    }


    const handleDelivererIDChange = (event) => {
        console.log(event.target.value);
        setDelivererID(event.target.value);
    };

    const handleStatusChange = (event) => {
      //console.log(event.target.value);
      setUpdatedStatus(event.target.value);
    };

    useEffect(() => {
        getData()
      }, 
      []
    )
    return (
    <div>
        <Box
          component="form"
          sx={{
            '& .MuiTextField-root': { m: 1, width: '40ch' },
          }}
          noValidate
          autoComplete="off"
        >
          <div>
            <TextField
              required
              id="filled-required"
              label="Deliverer ID"
              defaultValue=""
              variant="filled"
              value={delivererID}
              onChange={e => handleDelivererIDChange(e)}
            />
            <br></br>
            <Button variant="outlined" color="success" onClick={() => getData()}>Get Deliverer's Deliveries</Button>
          </div>

         </Box>
      <div style={{ height: 370, width: '100%' }}>
        <DataGrid
          rows={deliverer}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5]}
        />
      </div>

      <Box
          component="form"
          sx={{
            '& .MuiTextField-root': { m: 1, width: '25ch' },
          }}
          noValidate
          autoComplete="off"
        >
          <div>
            <TextField
                id="outlined-select-currency"
                disabled="true"
                value={updateSelectedID}      
              />
            <br></br>
            <TextField
                id="outlined-select-currency"
                disabled="true"
                value={updateSelectedTrackingCode}      
              />
            <br></br>

            <TextField
              id="outlined-select-currency"
              select
              label="Status"
              value={updatedStatus}
              onChange={handleStatusChange}
              helperText="Please select status"
            >
              {status_values && (status_values).map((option) => (
                <MenuItem key={option.id} value={option.value}>
                  {option.value}
                </MenuItem>
              ))}
            </TextField>
            <br></br>
            <Button variant="outlined" color="success" onClick={() => handleUpdateDelivery()}>Update Delivery</Button>
          </div>

        </Box>

      <br></br>
      <br></br>
    
    </div>
    );
}

export default DelivererPage;