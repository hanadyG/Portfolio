import React from "react";

function Home() {
    return <div style={{display: 'flex',  justifyContent:'center', alignItems:'center', fontSize: 40, paddingTop:'260px'}}>
                <strong>
                    Welcome to the new generation of Delivery Management Systems!
                </strong>
            </div>
}

export default Home;