import React, { useState, useEffect } from 'react'
import { DataGrid, getDataGridUtilityClass } from '@mui/x-data-grid';
import Button from '@mui/material/Button';
import axios from 'axios'
import { TextField } from '@mui/material';
import Box from '@mui/material/Box';
import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import MenuItem from '@mui/material/MenuItem'; 

function PickupBox() {
    const renderDetailsButton = (params) => {
        return (
            <strong>
                <Button name='Update'
                    variant="contained"
                    color="primary"
                    size="large"
                    style={{ marginLeft: 16, height: 30 }}
                    onClick={(e) => {
                        setName(pickupBox.filter(x => x.id == params.id)[0].name)
                        setAddress(pickupBox.filter(x => x.id == params.id)[0].address)
                        setUpdateSelectedID(params.id)
                        setButtonName("Update the PickupBox")
                    }}
                >
                    Update
                </Button>
            </strong>
        )
    }
    const columns = [
        { field: 'id', headerName: 'ID', width: 200 },
        { field: 'name', headerName: 'name', width: 200  },
        { field: 'address', headerName: 'address', width: 200  },
        { field: "trackingCodes", headerName: "tracking Code", flex: 1},
        {
            field: 'col5',
            headerName: 'Update',
            width: 150,
            renderCell: renderDetailsButton,
            disableClickEventBubbling: true,
        }
    ];

    const [pickupBox, setPickupBox] = useState({})
    const [buttonName, setButtonName] = useState("Create New PickupBox")
    const [selectedRows, setSelectedRows] = useState({})
    const [id, setId] = useState(1)
    const [idFromButtonClick, setIdFromButtonClick] = useState(1)

    const [name, setName] = useState('')
    const [address, setAddress] = useState('')
    const [trackingCodes, setTrackingCodes] = useState([])
    const [updateSelectedID, setUpdateSelectedID] = useState()

    const getData = () => {
        axios
            .get(process.env.REACT_APP_PUBLIC_URL + '/pickupbox')
            .then(res => {
              console.log(res)
              
              let arr = []
              if(Array.isArray(res.data)) {
                res.data.forEach(item =>
                                        {
                                            let trackingCodes = []
                                            if(item.deliveries){
                                            item.deliveries.forEach(delivery =>{
                                                if(delivery && delivery != undefined && delivery != null){
                                                  trackingCodes.push(delivery.trackingCode)
                                                }
                                              }
                                            )
                                            arr.push({
                                                id: item.id,
                                                name: item.name,
                                                address: item.address,
                                                trackingCodes: trackingCodes 
                                              })
                                            }
                                        }
                                )
                }
                setPickupBox(arr);
              })
            
    }

    const onDelete = (selectedRows) => {
        selectedRows.forEach(selectedRow =>{
                                console.log('id ' + selectedRow.id);
                                axios.delete(`http://localhost:8080/pickupbox/${selectedRow.id}`).then(() => {
                                getData()}) 
                              }
                            )
    }

    const handleNameChange = (event) => {
        console.log(event.target.value);
        setName(event.target.value);
    };

    const handleAddressChange = (event) => {
        console.log(event.target.value);
        setAddress(event.target.value);
    };

    const handleCreateNewPickupBox = () => {
        if(updateSelectedID != null && updateSelectedID != undefined)
        {
            console.log("geldi")
            var data = {
                "id": updateSelectedID,
                "name": name,
                "address": address
              }
              console.log(data)
              axios
              .put(process.env.REACT_APP_PUBLIC_URL + '/pickupbox/'+updateSelectedID, data)
              .then(res => {
                console.log(res)
                getData()
                }).catch(error => {
                  alert("Couldn't update the PickupBox. Try again with confirmed inputs");
                });
        }
        else
        {
            console.log("gelmedi")
            var data = {
                "name": name,
                "address": address
      
              }
              console.log(data)
              axios
              .post(process.env.REACT_APP_PUBLIC_URL + '/pickupbox', data)
              .then(res => {
                console.log(res)
                getData()
                }).catch(error => {
                    alert("Couldn't create new PickupBox. Try again with confirmed inputs");
                  });
        }
        
    
          
    }

    useEffect(() => {
        getData()
      }, 
      []
    )
    return (
    <div>
      <div style={{ height: 370, width: '100%' }}>
        <DataGrid
          rows={pickupBox}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
          onSelectionModelChange={(ids) => {
            const selectedIDs = new Set(ids);
            const selectedRowData = pickupBox.filter((row) =>
              selectedIDs.has(row.id.toString())
            );
            setSelectedRows(selectedRowData);
            if(selectedIDs.size != 1)
            {
                setUpdateSelectedID(null)
                setAddress("")
                setName("")
                setButtonName("Create New PickupBox")
            }
          }}
        />
        <Button variant="outlined" color="error" onClick={() => onDelete(selectedRows)}>Delete</Button>
      </div>
      <br></br>
      <br></br>
      <Box
          component="form"
          sx={{
            '& .MuiTextField-root': { m: 1, width: '25ch' },
          }}
          noValidate
          autoComplete="off"
        >
          <div>
            <TextField
              required
              id="filled-required"
              label="name"
              defaultValue=""
              variant="filled"
              value={name}
              onChange={e => handleNameChange(e)}
            />
            <br></br>
            <TextField
              required
              id="filled-required"
              label="address"
              defaultValue=""
              variant="filled"
              value={address}
              onChange={e => handleAddressChange(e)}
            />
            <br></br>
            <Button variant="outlined" color="success" onClick={() => handleCreateNewPickupBox()}>{buttonName}</Button>
          </div>

        </Box>
    </div>
    );
}

export default PickupBox;