import React, { useState, useEffect } from 'react'
import { DataGrid, getDataGridUtilityClass } from '@mui/x-data-grid';
import Button from '@mui/material/Button';
import axios from 'axios'
import { TextField } from '@mui/material';
import Box from '@mui/material/Box';
import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import MenuItem from '@mui/material/MenuItem';



function Dispatcher() {
  const renderDetailsButton = (params) => {
    return (
      <strong>
        <Button name='Update'
          variant="contained"
          color="primary"
          size="large"
          style={{ marginLeft: 16, height: 30 }}
          onClick={(e) => {
            console.log(params.row.email)
            setMail(params.row.email)
            setUpdateSelectedID(params.id)
            setSelectedMail(params.row.email)
            setButtonName("Update the Dispatcher")
          }}
        >
          Update
        </Button>
      </strong>
    )
  }
  const columns = [
    { field: 'id', headerName: 'ID', width: 120 },
    { field: 'email', headerName: 'Email', width: 200 },
    {
      field: 'col5',
      headerName: 'Update',
      width: 150,
      renderCell: renderDetailsButton,
      disableClickEventBubbling: true,
    }
  ];
  const [dispatcher, setDispatcher] = useState({})
  const [buttonName, setButtonName] = useState("Create New Delivery")
  const [selectedRows, setSelectedRows] = useState({})
  const [id, setId] = useState(1)
  const [idFromButtonClick, setIdFromButtonClick] = useState(1)
  const [updateSelectedID, setUpdateSelectedID] = useState()
  const [selectedmail, setSelectedMail] = useState('')
  const [mail, setMail] = useState('')
  const [password, setPassword] = useState('')

  const getData = () => {
    axios
      .get(process.env.REACT_APP_PUBLIC_URL + '/dispatcher')
      .then(res => {
        console.log(res)

        let arr = []
        if (Array.isArray(res.data)) {
          res.data.forEach(item =>
            arr.push({
              id: item.id,
              email: item.email
            })
          )
        }
        setDispatcher(arr);
      })

  }

  const onDelete = (selectedRows) => {
    selectedRows.forEach(selectedRow => {
      console.log('id ' + selectedRow.id);
      axios.delete(`http://localhost:8080/dispatcher/${selectedRow.id}`).then(() => {
        getData()
        axios.delete(`http://localhost:8081/aseUser/dispatcher/${selectedRow.email}`).then(() => {
          getData()
        })
      })
    }
    )
  }

  const handleMailChange = (event) => {
    console.log(event.target.value);
    setMail(event.target.value);
  };

  const handlePasswordChange = (event) => {
    console.log(event.target.value);
    setPassword(event.target.value);
  };

  const handleCreateNewDispatcher = () => {
    if (updateSelectedID != null && updateSelectedID != undefined) {
      console.log("geldi")
      var data = {
        "username": mail,
        "password": password,
        "userRole": "ROLE_DISPATCHER"
      }
      console.log(data)
      axios
        .put("http://localhost:8081/aseUser/dispatcher/" + selectedmail, data)
        .then(res => {
          var data = {
            "id": updateSelectedID,
            "email": mail
          }
          axios
            .put(process.env.REACT_APP_PUBLIC_URL + '/dispatcher/' + updateSelectedID, data)
            .then(res => {
              getData()
            })
        }).catch(error => {
          alert("Couldn't update the Dispatcher. Try again with confirmed inputs");
        });
    }
    else {
      var data = {
        "username": mail,
        "password": password,
        "userRole": "ROLE_DISPATCHER"
      }
      console.log(data)
      axios
        .post("http://localhost:8081/aseUser/dispatcher/", data)
        .then(res => {
          var data = {
            "email": mail,
          }
          axios
            .post(process.env.REACT_APP_PUBLIC_URL + '/dispatcher', data)
            .then(res => {
              getData()
            });
        }).catch(error => {
          alert("Couldn't create new Dispatcher. Try again with confirmed inputs");
        });
    }


  }

  useEffect(() => {
    getData()
  },
    []
  )
  return (
    <div>
      <div style={{ height: 370, width: '100%' }}>
        <DataGrid
          rows={dispatcher}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
          onSelectionModelChange={(ids) => {
            const selectedIDs = new Set(ids);
            const selectedRowData = dispatcher.filter((row) =>
              selectedIDs.has(row.id.toString())
            );
            setSelectedRows(selectedRowData);
            if (selectedIDs.size != 1) {
              setUpdateSelectedID(null)
              setMail("")
              setPassword("")
              setButtonName("Create New Dispatcher")
            }
          }}
        />
        <Button variant="outlined" color="error" onClick={() => onDelete(selectedRows)}>Delete</Button>
      </div>
      <br></br>
      <br></br>
      <Box
        component="form"
        sx={{
          '& .MuiTextField-root': { m: 1, width: '25ch' },
        }}
        noValidate
        autoComplete="off"
      >
        <div>
          <TextField
            required
            id="filled-required"
            label="mail"
            defaultValue=""
            variant="filled"
            value={mail}
            onChange={e => handleMailChange(e)}
          />
          <TextField
            required
            id="filled-required"
            label="Password"
            defaultValue=""
            variant="filled"
            value={password}
            onChange={e => handlePasswordChange(e)}
          />
          <br></br>
          <Button variant="outlined" color="success" onClick={() => handleCreateNewDispatcher()}>{buttonName}</Button>
        </div>

      </Box>
    </div>
  );
}

export default Dispatcher;