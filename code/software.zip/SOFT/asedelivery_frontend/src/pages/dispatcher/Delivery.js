import React, { useState, useEffect } from 'react'
import { DataGrid, getDataGridUtilityClass } from '@mui/x-data-grid';
import Button from '@mui/material/Button';
import axios from 'axios'
import { TextField } from '@mui/material';
import Box from '@mui/material/Box';
import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import MenuItem from '@mui/material/MenuItem';


const status_values = [
  {
    id: 1,
    value: 'ordered'
  },
  {
    id: 2,
    value: 'picked-up'
  },
  {
    id: 3,
    value: 'delivered'
  },
  {
    id: 4,
    value: 'collected'
  },
  {
    id: 5,
    value: 'cancelled'
  }
];

export default function Delivery() {
  const renderDetailsButton = (params) => {
    return (
      <strong>
        <Button name='Update'
          variant="contained"
          color="primary"
          size="large"
          style={{ marginLeft: 16, height: 30 }}
          onClick={(e) => {
            setTrackingCode(params.row.trackingCode)
            setStatus(params.row.status)
            let selectedCustomerID = dropDownCustomer.filter(x => x.email == params.row.customerEmail)[0].id;
            setSelectedCustomer(selectedCustomerID)
            setSelectedDeliverer(dropDownDeliverer.filter(x => x.email == params.row.delivererEmail)[0].id)
            setSelectedPickupBox(dropDownPickupBox.filter(x => x.address == params.row.pickupBoxAddress)[0].id)
            setUpdateSelectedID(params.row.id)
            setButtonName("Update The Delivery")
            setRelatedPickupBox(selectedCustomerID)
          }}
        >
          Update
        </Button>
      </strong>
    )
  }
  const columns = [
    { field: 'id', headerName: 'ID', flex: 1 },
    { field: 'trackingCode', headerName: 'Tracking Code', width: 120 },
    { field: 'status', headerName: 'Status', width: 100 },
    { field: 'pickupBoxName', headerName: 'Pickupbox Name', flex: 1 },
    { field: 'pickupBoxAddress', headerName: 'PickupBox Address', flex: 1 },
    { field: 'customerEmail', headerName: 'Customer Email', flex: 1 },
    { field: 'delivererEmail', headerName: 'Deliverer Email', flex: 1 },
    {
      field: 'col5',
      headerName: 'Update',
      width: 150,
      renderCell: renderDetailsButton,
      disableClickEventBubbling: true,
    }
  ];

  const [delivery, setDelivery] = useState({})

  const [buttonName, setButtonName] = useState("Create New Delivery")

  const [dropDownCustomer, setDropDownCustomer] = useState([])
  const [selectedCustomer, setSelectedCustomer] = useState('')

  const [dropDownDeliverer, setDropDownDeliverer] = useState([])
  const [selectedDeliverer, setSelectedDeliverer] = useState('')

  const [dropDownPickupBox, setDropDownPickupBox] = useState([])
  const [allPickupBox, setAllPickupBox] = useState([])
  const [selectedPickupBox, setSelectedPickupBox] = useState('')

  const [status, setStatus] = useState('')
  const [trackingCode, setTrackingCode] = useState('')

  const [selectedRows, setSelectedRows] = useState({})
  const [id, setId] = useState(1)
  const [idFromButtonClick, setIdFromButtonClick] = useState(1)
  const [updateSelectedID, setUpdateSelectedID] = useState()
  const getData = () => {
    axios
      .get(process.env.REACT_APP_PUBLIC_URL + '/delivery')
      .then(res => {
        //console.log(res)

        let arr = []
        if (Array.isArray(res.data)) {
          res.data.forEach(item =>
            arr.push({
              id: item.id,
              status: item.status,
              trackingCode: item.trackingCode,
              pickupBoxName: item.pickupBox.name,
              pickupBoxAddress: item.pickupBox.address,
              customerEmail: (item.customer) && item.customer.email ? item.customer.email : "No customer",
              delivererEmail: (item.deliverer) && item.deliverer.email ? item.deliverer.email : "No Deliverer",
            })
          )
        }
        //console.log(arr);
        setDelivery(arr);
      })

  }

  const setRelatedPickupBox = (customerId) => {
    console.log(allPickupBox);
    console.log(allPickupBox.filter(x => x.customer_id == customerId || x.customer_id == null || x.customer_id == undefined))
    setDropDownPickupBox(allPickupBox.filter(x => x.customer_id == customerId || x.customer_id == null || x.customer_id == undefined))
  }

  const handleCustomerChange = (event) => {
    setSelectedCustomer(event.target.value);
    setRelatedPickupBox(event.target.value);
  };

  const handleDelivererChange = (event) => {
    setSelectedDeliverer(event.target.value);
  };

  const handlePickupBoxChange = (event) => {
    setSelectedPickupBox(event.target.value);
  };

  const handleStatusChange = (event) => {
    //console.log(event.target.value);
    setStatus(event.target.value);
  };

  const handleTrackingCodeChange = (event) => {
    //console.log(event.target.value);
    setTrackingCode(event.target.value);
  };

  const getCustomers = () => {
    axios
      .get(process.env.REACT_APP_PUBLIC_URL + '/customer')
      .then(res => {
        //console.log(res)

        let arr = []
        if (Array.isArray(res.data)) {
          res.data.forEach(item =>
            arr.push({
              id: item.id,
              email: item.email,
            })
          )
        }
        setDropDownCustomer(arr);
      })
  }

  const getDeliverers = () => {
    axios
      .get(process.env.REACT_APP_PUBLIC_URL + '/deliverer')
      .then(res => {
        //console.log(res)

        let arr = []
        if (Array.isArray(res.data)) {
          res.data.forEach(item =>
            arr.push({
              id: item.id,
              email: item.email,
            })
          )
        }
        setDropDownDeliverer(arr);
      })
  }

  const getPickupBoxes = () => {
    axios
      .get(process.env.REACT_APP_PUBLIC_URL + '/pickupbox')
      .then(res => {
        //console.log(res)

        let arr = []
        if (Array.isArray(res.data)) {
          res.data.forEach(item =>
            arr.push({
              id: item.id,
              name: item.name,
              address: item.address,
              customer_id: item.customer && item.customer.id
            })
          )
        }
        setAllPickupBox(arr);
        setDropDownPickupBox(arr);
      })
  }

  const onDelete = (selectedRows) => {
    selectedRows.forEach(selectedRow => {
      //console.log('id ' + selectedRow.id);
      axios.delete(`http://localhost:8080/delivery/${selectedRow.id}`).then(() => {
        getData()
      })
    }
    )
  }

  const handleCreateNewDelivery = () => {
    if (updateSelectedID != null && updateSelectedID != undefined) {
      console.log(updateSelectedID)
      var data = {
        "id": updateSelectedID,
        "status": status,
        "trackingCode": trackingCode,
        "deliverer": {
          "id": selectedDeliverer
        },
        "pickupBox": {
          "id": selectedPickupBox
        },
        "customer": {
          "id": selectedCustomer
        }
      }
      //console.log(data)
      axios
        .put(process.env.REACT_APP_PUBLIC_URL + '/delivery/' + updateSelectedID, data)
        .then(res => {
          //console.log(res)
          getData()
        }).catch(error => {
          alert("Couldn't update the Delivery. Try again with confirmed inputs");
        });
    }
    else {
      console.log(updateSelectedID)
      var data = {
        "status": status,
        "trackingCode": trackingCode,
        "deliverer": {
          "id": selectedDeliverer
        },
        "pickupBox": {
          "id": selectedPickupBox
        },
        "customer": {
          "id": selectedCustomer
        }
      }
      console.log(data)
      axios
        .post(process.env.REACT_APP_PUBLIC_URL + '/delivery', data)
        .then(res => {
          //console.log(res)
          getData()
        }).catch(error => {
          alert("Couldn't create new Delivery. Try again with confirmed inputs");
        });
    }


  }

  useEffect(() => {
    getData()
    getCustomers()
    getPickupBoxes()
    getDeliverers()
  },
    []
  )

  return (
    <div>
      <div style={{ height: 370, width: '100%' }}>
        <DataGrid
          rows={delivery}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
          onSelectionModelChange={(ids) => {
            const selectedIDs = new Set(ids);
            const selectedRowData = delivery.filter((row) =>
              selectedIDs.has(row.id.toString())
            );
            console.log(delivery);
            setSelectedRows(selectedRowData);
            if (selectedIDs.size != 1) {
              setUpdateSelectedID(null)
              setSelectedCustomer("")
              setSelectedDeliverer("")
              setSelectedPickupBox("")
              setStatus("")
              setTrackingCode("")
              setRelatedPickupBox("")
              setDropDownPickupBox(allPickupBox)
              setButtonName("Create New Delivery")
            }
          }}
        />
        <Button variant="outlined" color="error" onClick={() => onDelete(selectedRows)}>Delete</Button>
        <br></br>
        <Box
          component="form"
          sx={{
            '& .MuiTextField-root': { m: 1, width: '25ch' },
          }}
          noValidate
          autoComplete="off"
        >
          <div>
            <TextField
              id="outlined-select-currency"
              select
              label="Status"
              value={status}
              onChange={handleStatusChange}
              helperText="Please select status"
            >
              {status_values && (status_values).map((option) => (
                <MenuItem key={option.id} value={option.value}>
                  {option.value}
                </MenuItem>
              ))}
            </TextField>
            <br></br>
            <TextField
              required
              id="filled-required"
              label="Tracking Code"
              defaultValue=""
              variant="filled"
              value={trackingCode}
              onChange={e => handleTrackingCodeChange(e)}
            />
            <br></br>
            <TextField
              id="outlined-select-currency"
              select
              label="Customer"
              value={selectedCustomer}
              onChange={handleCustomerChange}
              helperText="Please select your customer"
            >
              {dropDownCustomer && (dropDownCustomer).map((option) => (
                <MenuItem key={option.id} value={option.id}>
                  {option.email}
                </MenuItem>
              ))}
            </TextField>
            <br></br>
            <TextField
              id="outlined-select-currency"
              select
              label="Deliverer"
              value={selectedDeliverer}
              onChange={handleDelivererChange}
              helperText="Please select your deliverer"
            >
              {dropDownDeliverer && (dropDownDeliverer).map((option) => (
                <MenuItem key={option.id} value={option.id}>
                  {option.email}
                </MenuItem>
              ))}
            </TextField>
            <br></br>
            <TextField
              id="outlined-select-currency"
              select
              label="PickupBox"
              value={selectedPickupBox}
              onChange={handlePickupBoxChange}
              helperText="Please select your pickupbox"
            >
              {dropDownPickupBox && (dropDownPickupBox).map((option) => (
                <MenuItem key={option.id} value={option.id}>
                  {option.address}
                </MenuItem>
              ))}
            </TextField>
            <br></br>
            <Button variant="outlined" color="success" onClick={() => handleCreateNewDelivery()}>{buttonName}</Button>
          </div>

        </Box>
        <br></br>
        <br></br>
        <br></br>
      </div>
    </div>
  );
}
