package edu.tum.ase.project.service;

import java.util.Base64;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.security.Principal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.context.SecurityContext;
import edu.tum.ase.project.jwt.JwtUtil;
import org.springframework.http.HttpStatus;
import edu.tum.ase.project.model.AseUser;
import edu.tum.ase.project.model.UserRole;
import org.springframework.web.reactive.function.client.WebClient;

import javax.servlet.http.Cookie;

@RestController
public class AuthService {
    @Autowired
    private AuthenticationManager authManager;
    @Autowired
    private PasswordEncoder bcryptPasswordEncoder;
    @Autowired
    private MyUserDetailsService mongoUserDetailsService;

    /*
     * public ResponseEntity<String> authenticateUser(
     * String authorization,
     * HttpServletRequest request) throws Exception {
     * System.out.println("authenticate");
     * Principal principal = request.getUserPrincipal();
     * System.out.println(principal.getName());
     * System.out.println(principal.toString());
     * String password_en = authorization.split(" ")[1];
     * String decode = new String(Base64.getDecoder().decode(password_en));
     * System.out.println(decode);
     * String[] temp = decode.split(":");
     * String password = temp[1];
     * 
     * try {
     * UsernamePasswordAuthenticationToken upt = new
     * UsernamePasswordAuthenticationToken(principal, password);
     * Authentication auth = authManager.authenticate(upt);
     * SecurityContext sc = SecurityContextHolder.getContext();
     * sc.setAuthentication(auth);
     * if (sc.getAuthentication().isAuthenticated()) {
     * return ResponseEntity.ok(principal.getName());
     * } else {
     * return ResponseEntity.ok("nope");
     * }
     * } catch (Exception e) {
     * return ResponseEntity.ok("nope");
     * }
     * 
     * }
     */

    @Autowired
    private JwtUtil jwtUtil;

    public void setAuthentication(UserDetails details, HttpServletRequest request) {
        Principal principal = request.getUserPrincipal();
        UsernamePasswordAuthenticationToken upt = new UsernamePasswordAuthenticationToken(principal,
                details.getPassword());
        Authentication auth = authManager.authenticate(upt);
        SecurityContext sc = SecurityContextHolder.getContext();
        sc.setAuthentication(auth);
    }

    public UserDetails getAuthentication() {
        UserDetails details = null;
        SecurityContext sc = SecurityContextHolder.getContext();
        Authentication auth = sc.getAuthentication();
        if (auth != null) {
            details = (UserDetails) auth.getPrincipal();
        }
        return details;
    }

    public ResponseEntity<String> authenticateUser(
            String authorization,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
        System.out.println("authenticate");

        String password_en = authorization.split(" ")[1];
        String decode = new String(Base64.getDecoder().decode(password_en));
        System.out.println(decode);
        String[] temp = decode.split(":");
        String username = temp[0];
        String password = temp[1];

        final UserDetails userDetails = mongoUserDetailsService.loadUserByUsername(username);
        if (bcryptPasswordEncoder.matches(password,
                userDetails.getPassword())) {
            AseUser user = new AseUser();
            user.setPassword(userDetails.getPassword());
            user.setUsername(userDetails.getUsername());
            user.setUserRole(userDetails.getAuthorities().toString());
            final String jwt = jwtUtil.generateToken(user);
            Cookie jwtCookie = new Cookie("jwt", jwt);
            jwtCookie.setHttpOnly(true);
            jwtCookie.setMaxAge(36000);
            response.addCookie(jwtCookie);
            /*
             * WebClient client = WebClient.create("http://localhost:8080");
             * client.get().uri("/auth").cookie("jwt", jwt).retrieve();
             */

            return new ResponseEntity<String>(HttpStatus.OK);
        } else {
            return new ResponseEntity<String>(
                    "Email or password is incorrect",
                    HttpStatus.BAD_REQUEST);
        }
    }

    public ResponseEntity<String> deauthenticateUser(
            HttpServletResponse response) throws Exception {
        SecurityContextHolder.clearContext();
        Cookie jwtCookie = new Cookie("jwt", null);
        jwtCookie.setHttpOnly(true);
        jwtCookie.setMaxAge(0);
        jwtCookie.setPath("/");
        response.addCookie(jwtCookie);

        return new ResponseEntity<String>(HttpStatus.OK);
    }
}
