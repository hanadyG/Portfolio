package edu.tum.ase.project.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import edu.tum.ase.project.service.AuthService;
import org.springframework.security.core.userdetails.UserDetails;

@RestController
@RequestMapping("")
public class DefaultController {

    @Autowired
    private AuthService authService;

    @GetMapping()
    @RequestMapping("")
    public ResponseEntity<String> deauthenticateUser() {
        UserDetails details = authService.getAuthentication();
        String res = details.getUsername() + ":" + details.getAuthorities().toString();
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @GetMapping()
    @RequestMapping("/check/customer")
    public ResponseEntity<String> checkAuthCustomer() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping()
    @RequestMapping("/check/deliverer")
    public ResponseEntity<String> checkAuthDeliverer() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping()
    @RequestMapping("/check/dispatcher")
    public ResponseEntity<String> checkAuthDispatcher() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping()
    @RequestMapping("/check/delivery")
    public ResponseEntity<String> checkAuthDelivery() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping()
    @RequestMapping("/check/pickupbox")
    public ResponseEntity<String> checkAuthPickupbox() {
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
