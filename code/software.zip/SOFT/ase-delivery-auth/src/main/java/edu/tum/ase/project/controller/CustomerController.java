package edu.tum.ase.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController

@RequestMapping("/customer")
public class CustomerController {

    @GetMapping("")
    public ResponseEntity<String> getAllCustomers() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("deliveries/{id}")
    public ResponseEntity<String> getDeliveriesOfCustomer() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("")
    public ResponseEntity<String> createCustomer() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateCustomer() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCustomer() {
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
