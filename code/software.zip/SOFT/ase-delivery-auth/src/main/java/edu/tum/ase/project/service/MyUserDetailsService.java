package edu.tum.ase.project.service;

import edu.tum.ase.project.model.AseUser;
import edu.tum.ase.project.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonTypeInfo.As;

@Component
public class MyUserDetailsService implements UserDetailsService {
    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        AseUser user = userRepository.findByUsername(userName);
        System.out.println(user.getUsername());
        UserDetails details = User.builder().username(user.getUsername())
                .password(user.getPassword())
                .roles(user.getRole())
                .build();
        return details;
    }

    public AseUser findbyUsername(String userName) throws UsernameNotFoundException {
        return userRepository.findByUsername(userName);
    }

    public AseUser createAseUser(AseUser aseUser) {
        AseUser createdUser = userRepository.insert(aseUser);
        return createdUser;
    }

    public void deleteById(String id) {
        userRepository.deleteByUsername(id);
    }

    public AseUser update(AseUser user) {
        return userRepository.save(user);
    }
}
/*
 * @Component
 * public class MongoUserDetailsService implements UserDetailsService {
 * 
 * @Autowired
 * private UserRepository userRepository;
 * 
 * @Override
 * public UserDetails loadUserByUsername(String userName) throws
 * UsernameNotFoundException {
 * List<AseUser> allUsers = userRepository.findAll();
 * return userRepository.findByUsername(userName);
 * 
 * //AseUser ua = allUsers.stream().filter(a -> a.getUserName() ==
 * username).findFirst().get();
 * 
 * // username, password and authority that we retrieved above
 * }
 * }
 */