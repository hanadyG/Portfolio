package edu.tum.ase.project;

import com.mongodb.client.MongoClient;
import edu.tum.ase.project.model.AseUser;
import edu.tum.ase.project.model.UserRole;
import edu.tum.ase.project.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
@EnableMongoRepositories(basePackageClasses = {})
public class ProjectApplication implements CommandLineRunner {
	private static final Logger log = LoggerFactory.getLogger(ProjectApplication.class);

	@Autowired
	MongoClient mongoClient;

	@Autowired
	MyUserDetailsService userService;

	public static void main(String[] args) {
		SpringApplication.run(ProjectApplication.class, args);
	}

	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurer() {

			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/**")
						.allowedMethods("POST", "GET", "PUT", "OPTIONS", "HEAD", "DELETE")
						.allowedOrigins("http://localhost:8080", "http://localhost:3000", "http://ase-delivery-data:8080")
						.allowCredentials(true);
			}
		};
	}

	/*
	 * @Bean
	 * public CorsFilter corsFilter() {
	 * final UrlBasedCorsConfigurationSource source = new
	 * UrlBasedCorsConfigurationSource();
	 * final CorsConfiguration config = new CorsConfiguration();
	 * config.setAllowCredentials(true);
	 * // Don't do this in production, use a proper list of allowed origins
	 * config.setAllowedOrigins(Collections.singletonList("http://localhost:3000"));
	 * // config.setAllowedHeaders(Arrays.asList("Origin",
	 * "Content-Type","Accept"));
	 * /*
	 * config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "OPTIONS",
	 * "DELETE", "PATCH"));
	 * 
	 * source.registerCorsConfiguration("/**",config);return new CorsFilter(source);
	 * 
	 * }
	 */

	@Override
	public void run(String... args) throws Exception {
		log.info("MongoClient = " + mongoClient.getClusterDescription());
		try
		{
			userService.loadUserByUsername("dispatcher_1@mail.com");
		}
		catch(Exception e)
		{
			AseUser aseUser = new AseUser();
			aseUser.setUsername("dispatcher_1@mail.com");
			BCryptPasswordEncoder bc = new BCryptPasswordEncoder();
			aseUser.setPassword(bc.encode("helloworld"));
			aseUser.setUserRole(UserRole.DISPATCHER);
			AseUser createdCustomer = userService.createAseUser(aseUser);
			System.out.println("dispatcher1 created!");
		}
		/*
		 * AseUser aseUser = new AseUser();
		 * aseUser.setUsername("deliverer_1@mail.com");
		 * BCryptPasswordEncoder bc = new BCryptPasswordEncoder();
		 * aseUser.setPassword(bc.encode("helloworld"));
		 * aseUser.setUserRole(UserRole.CUSTOMER);
		 * AseUser createdCustomer = userService.createAseUser(aseUser);
		 * 
		 * Customer customer = customerService.createCustomer(new
		 * Customer("johnwick@asd.com"));
		 * Deliverer deliverer = delivererService.createDeliverer(new
		 * Deliverer("matrixneo@asd.com"));
		 * // Customer customer = customerService.findByEmail("asd@bla.com");
		 * // Deliverer deliverer =
		 * delivererService.findByEmail("deliverirAliAliAli@bla.com");
		 * 
		 * Random rand = new Random();
		 * int numb = rand.nextInt(100000);
		 * String trackingCode = Integer.toString(numb);
		 * String trackingCode2 = "999999";
		 * PickupBox p = pickupBoxService.createPickupBox(new
		 * PickupBox("newname","newaddress"));
		 * Delivery d = new Delivery("active",trackingCode2, customer, deliverer, p);
		 * Delivery created_delivery = deliveryService.createDelivery(d);
		 * 
		 * //deliveryService.deleteDelivery(deliveryService.findByTrackingCode("12345"))
		 * ;
		 * 
		 * PickupBox created_pickupBox = pickupBoxService.createPickupBox(new
		 * PickupBox("ocean", "munich"));
		 * //Delivery d = new Delivery("active","123456",
		 * customerService.findByEmail("asd@bla.com"),
		 * delivererService.findByEmail("deliverirAli@bla.com"), created_pickupBox);
		 * //Delivery created_delivery = deliveryService.createDelivery(d);
		 * 
		 * pickupBoxService.setCustomer(created_pickupBox,
		 * customerService.findByEmail("asd@bla.com"));
		 * pickupBoxService.addDeliverer(created_pickupBox,
		 * delivererService.findByEmail("deliverirAli@bla.com"));
		 * pickupBoxService.addDelivery(created_pickupBox, created_delivery);
		 * List<Deliverer> delivererList = delivererService.getAllDeliverers();
		 * log.info("Number of Project in Database is " + delivererList.size());
		 * log.info(String.format("Customer %s is created with id %s",
		 * delivererList.get(0).getEmail(),
		 * delivererList.get(0).getDeliveries()));
		 * 
		 */

	}
}
