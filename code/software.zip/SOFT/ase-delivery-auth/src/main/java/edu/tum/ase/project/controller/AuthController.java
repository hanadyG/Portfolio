package edu.tum.ase.project.controller;

import edu.tum.ase.project.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping()
    public ResponseEntity<String> authenticateUser(@RequestHeader("authorization") String request,
            HttpServletRequest request2, HttpServletResponse response) {
        try {
            System.out.println("authenticate user ici");
            System.out.println(request);

            return authService.authenticateUser(request, request2, response);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok("asd");
        }
    }

    @GetMapping()
    @RequestMapping("/logout")
    public ResponseEntity<String> deauthenticateUser(HttpServletResponse response) {
        try {
            return authService.deauthenticateUser(response);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok("asd");
        }
    }
}