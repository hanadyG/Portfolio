package edu.tum.ase.project.jwt;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.*;
import java.security.cert.Certificate;
import java.io.*;
import org.springframework.util.ResourceUtils;

@Component
public class KeyStoreManager {
    private KeyStore keyStore;
    private String keyAlias;
    private char[] password = "tennis123".toCharArray();

    public KeyStoreManager() throws KeyStoreException, IOException {
        loadKeyStore();
    }

    public void loadKeyStore() throws KeyStoreException, IOException {
        keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        FileInputStream fis = null;
        try {
            // Get the path to the keystore file in the resources folder
            InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("classpath:ase_project.keystore");
            File keystoreFile = new File("x.txt");// = ResourceUtils.getFile("classpath:ase_project.keystore");
            Files.copy(inputStream, keystoreFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            //File keystoreFile = ResourceUtils.getFile("classpath:ase_project.keystore");
            fis = new FileInputStream(keystoreFile);

            //fis = (FileInputStream) this.getClass().getClassLoader().getResourceAsStream("classpath:ase_project.keystore");
            keyStore.load(fis, password);
            keyAlias = keyStore.aliases().nextElement();
        } catch (Exception e) {
            System.err.println("Error when loading KeyStore");
            e.printStackTrace();
        } finally {
            if (fis != null) {
                fis.close();
            }
        }
    }

    protected PublicKey getPublicKey() {
        try {
            Certificate cert = keyStore.getCertificate(keyAlias);
            return cert.getPublicKey();
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    protected Key getPrivateKey() {
        try {
            KeyStore.ProtectionParameter entryPassword = new KeyStore.PasswordProtection(password);
            KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry) keyStore.getEntry(keyAlias,
                    entryPassword);
            return privateKeyEntry.getPrivateKey();
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}