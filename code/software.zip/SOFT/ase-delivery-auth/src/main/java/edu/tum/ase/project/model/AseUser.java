package edu.tum.ase.project.model;

import com.mongodb.lang.NonNull;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;

@Document(collection = "users")
public class AseUser implements UserDetails {
    @Indexed(unique = true)
    private String username;

    private String password;

    private UserRole userRole;

    public AseUser() {
    }

    public AseUser(UserDetails detail) {
        this.username = detail.getUsername();
        this.password = detail.getPassword();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }

    public String getPassword() {
        return this.password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }

    public String getRole() {
        return this.userRole.toString();
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUserRole(UserRole role) {
        userRole = role;
    }

    public void setUserRole(String role) {
        if (role.equals("Role_DISPATCHER") || role.equals("[ROLE_DISPATCHER]")) {
            userRole = UserRole.DISPATCHER;
        } else if (role.equals("Role_DELIVERER") || role.equals("[ROLE_DELIVERER]")) {
            userRole = UserRole.DELIVERER;
        } else if (role.equals("Role_CUSTOMER") || role.equals("[ROLE_CUSTOMER]")) {
            userRole = UserRole.CUSTOMER;
        }
    }

}
