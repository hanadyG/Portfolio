package edu.tum.ase.project.model;

public enum UserRole {
    DISPATCHER, DELIVERER, CUSTOMER
}
