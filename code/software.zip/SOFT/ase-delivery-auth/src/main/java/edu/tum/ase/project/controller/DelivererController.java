package edu.tum.ase.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.config.EnableReactiveMongoAuditing;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController

@RequestMapping("/deliverer")
public class DelivererController {

    @GetMapping("")
    public ResponseEntity<String> getAllDeliverers() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("deliveries/{id}")
    public ResponseEntity<String> getDeliveriesOfDeliverer() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("")
    public ResponseEntity<String> createDeliverer() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateDeliverer() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PutMapping("/update_delivery/{id}")
    public ResponseEntity<String> updateDelivery() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteDeliverer() {
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
