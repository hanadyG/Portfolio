package edu.tum.ase.project.controller;

import edu.tum.ase.project.service.AuthService;
import edu.tum.ase.project.service.MyUserDetailsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import edu.tum.ase.project.model.AseUser;
import edu.tum.ase.project.model.UserRole;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.HttpStatus;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@RestController
@RequestMapping("/aseUser")
public class AseUserController {

    @Autowired
    private AuthService authService;

    @Autowired
    private MyUserDetailsService userService;

    @PostMapping("/customer")
    public ResponseEntity<AseUser> createCustomer(@RequestBody AseUser aseUser) {
        return create(aseUser, UserRole.CUSTOMER);
    }

    @DeleteMapping("/customer/{id}")
    public ResponseEntity<AseUser> deleteCustomer(@PathVariable("id") String id) {
        return delete(id);
    }

    @PutMapping("customer/{id}")
    public ResponseEntity<AseUser> updateCustomer(@PathVariable("id") String id, @RequestBody AseUser newCustomer) {
        return update(id, newCustomer);
    }

    @PostMapping("/deliverer")
    public ResponseEntity<AseUser> createDeliverer(@RequestBody AseUser aseUser) {
        return create(aseUser, UserRole.DELIVERER);
    }

    @DeleteMapping("/deliverer/{id}")
    public ResponseEntity<AseUser> deleteDeliverer(@PathVariable("id") String id) {
        return delete(id);
    }

    @PutMapping("deliverer/{id}")
    public ResponseEntity<AseUser> updateDeliverer(@PathVariable("id") String id, @RequestBody AseUser newDeliverer) {
        return update(id, newDeliverer);

    }

    @PostMapping("/dispatcher")
    public ResponseEntity<AseUser> createDispatcher(@RequestBody AseUser aseUser) {
        return create(aseUser, UserRole.DISPATCHER);
    }

    @DeleteMapping("/dispatcher/{id}")
    public ResponseEntity<AseUser> deleteDispatcher(@PathVariable("id") String id) {
        if (authService.getAuthentication().getUsername().equals(id)) {
            return delete(id);
        } else {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
    }

    @PutMapping("dispatcher/{id}")
    public ResponseEntity<AseUser> updateDispatcher(@PathVariable("id") String id, @RequestBody AseUser newDispatcher) {
        if (authService.getAuthentication().getUsername().equals(id)) {
            return update(id, newDispatcher);
        } else {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
    }

    private ResponseEntity<AseUser> create(AseUser aseUser, UserRole role) {
        try {
            if (authService.getAuthentication().getAuthorities().toString().contains("DISPATCHER")) {
                try {
                    userService.loadUserByUsername(aseUser.getUsername());
                    return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
                } catch (NullPointerException e) {
                    BCryptPasswordEncoder bc = new BCryptPasswordEncoder();
                    aseUser.setPassword(bc.encode(aseUser.getPassword()));
                    aseUser.setUserRole(role);
                    AseUser createdCustomer = userService.createAseUser(aseUser);
                    return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
                }
            } else {
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            System.out.println(e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private ResponseEntity<AseUser> update(String id, AseUser newUser) {
        try {
            if (authService.getAuthentication().getAuthorities().toString().contains("DISPATCHER")
                    || authService.getAuthentication().getUsername().equals(id)) {
                try {
                    userService.loadUserByUsername(newUser.getUsername());
                    return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
                } catch (NullPointerException e) {
                    AseUser user = userService.findbyUsername(id);
                    user.setUsername(newUser.getUsername());
                    if (!newUser.getPassword().equals("")) {
                        BCryptPasswordEncoder bc = new BCryptPasswordEncoder();
                        user.setPassword(bc.encode(newUser.getPassword()));
                    }
                    userService.deleteById(id);
                    return new ResponseEntity<>(userService.update(user), HttpStatus.OK);
                }
            } else {
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            System.out.println(e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<AseUser> delete(String id) {
        try {
            if (authService.getAuthentication().getAuthorities().toString().contains("DISPATCHER")
                    || authService.getAuthentication().getUsername().equals(id)) {
                userService.deleteById(id);
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            } else {
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            System.out.println(e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
