package edu.tum.ase.project.repository;

import edu.tum.ase.project.model.AseUser;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface UserRepository extends MongoRepository<AseUser, String> {
    // TODO: Write a function to find the project by Name
    List<AseUser> findAll();

    AseUser findByUsername(String username);

    AseUser deleteByUsername(String username);

}