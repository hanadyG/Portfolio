package edu.tum.ase.project.filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import javax.servlet.http.HttpServletRequest;
import edu.tum.ase.project.jwt.JwtUtil;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import java.io.*;
import org.springframework.web.filter.OncePerRequestFilter;
import edu.tum.ase.project.service.MyUserDetailsService;
import edu.tum.ase.project.service.AuthService;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;

@Component
public class AuthRequestFilter extends OncePerRequestFilter {

    @Autowired
    private MyUserDetailsService mongoUserDetailsService;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private AuthService authService;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {
        String username = null;
        String jwt = null;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                if (cookies[i].getName().equals("jwt")) {
                    jwt = cookies[i].getValue();
                }
            }
        }
        final String authHeader = request.getHeader("Authorization");
        System.out.println("Authenticate Header " + authHeader);
        if (jwt != null) {
            username = jwtUtil.extractUsername(jwt);
            System.out.println("jwt works");
        }
        /*
         * else if (authHeader == null || !authHeader.startsWith("Basic")) {
         * response.sendError(HttpStatus.BAD_REQUEST.value(),
         * "No JWT Token or Basic Auth Info Found");
         * } else {
         * System.out.println("jwt is null");
         * }
         */
        /*
         * if (authHeader != null && authHeader.startsWith("Bearer")) {
         * try {
         * String header = request.getHeader("authorization");
         * jwt = header.split(" ")[1];
         * username = jwtUtil.extractUsername(jwt);
         * } catch (Exception e) {
         * response.sendError(HttpStatus.BAD_REQUEST.value(),
         * "No JWT Token or Basic Auth Info Found");
         * }
         * 
         * } else {
         * // No valid authentication, No go
         * if (authHeader == null || !authHeader.startsWith("Basic")) {
         * response.sendError(HttpStatus.BAD_REQUEST.value(),
         * "No JWT Token or Basic Auth Info Found");
         * }
         * }
         */
        if (username != null &&
                SecurityContextHolder.getContext().getAuthentication() == null) {
            authService.setAuthentication(mongoUserDetailsService.loadUserByUsername(username), request);
            Authentication authContext = SecurityContextHolder.getContext().getAuthentication();
            System.out.println(String.format("Authenticate Token Set:\n"
                    + "Username: %s\n"
                    + "Password: %s\n"
                    + "Authority: %s\n",
                    authContext.getPrincipal(),
                    authContext.getCredentials(),
                    authContext.getAuthorities().toString()));
        } else {
            Authentication authContext = SecurityContextHolder.getContext().getAuthentication();
            System.out.println(String.format("Authenticate Token Set:\n"
                    + "Username: %s\n"
                    + "Password: %s\n"
                    + "Authority: %s\n",
                    authContext.getPrincipal(),
                    authContext.getCredentials(),
                    authContext.getAuthorities().toString()));
        }
        filterChain.doFilter(request, response);
    }
}
