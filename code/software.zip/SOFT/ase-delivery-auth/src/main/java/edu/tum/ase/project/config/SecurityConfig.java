package edu.tum.ase.project.config;

//import org.springframework.context.annotation.Configuration;

import edu.tum.ase.project.service.MyUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.cors.*;
import org.springframework.security.web.csrf.*;

@Configuration
// @EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    MyUserDetailsService mongoUserDetailsService;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.cors()
                .and()
                .csrf().disable()
                /*
                 * .csrf().csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()).
                 * and()
                 */
                .authorizeRequests()
                .antMatchers("/auth").permitAll()
                /*
                 * .antMatchers("/dispatcher").hasAuthority("ROLE_DISPATCHER")
                 * .antMatchers("/pickupbox").hasAuthority("ROLE_DISPATCHER")
                 * .antMatchers("/pickupbox").hasAuthority("ROLE_DELIVERER")
                 * .antMatchers("/deliverer").hasAuthority("ROLE_DISPATCHER")
                 * .antMatchers("/deliverer").hasAuthority("ROLE_DELIVERER")
                 */
                .antMatchers("/check/customer").hasAnyAuthority("ROLE_CUSTOMER", "ROLE_DISPATCHER")
                .antMatchers("/check/deliverer").hasAnyAuthority("ROLE_DELIVERER", "ROLE_DISPATCHER")
                .antMatchers("/check/dispatcher").hasAuthority("ROLE_DISPATCHER")
                .antMatchers("/aseUser").hasAuthority("ROLE_DISPATCHER")
                .antMatchers("/aseUser/customer").hasAnyAuthority("ROLE_CUSTOMER", "ROLE_DISPATCHER")
                .antMatchers("/aseUser/customer/**").hasAnyAuthority("ROLE_CUSTOMER", "ROLE_DISPATCHER")
                .antMatchers("/aseUser/deliverer").hasAnyAuthority("ROLE_DELIVERER", "ROLE_DISPATCHER")
                .antMatchers("/aseUser/deliverer/**").hasAnyAuthority("ROLE_DELIVERER", "ROLE_DISPATCHER")
                .antMatchers("/aseUser/dispatcher").hasAuthority("ROLE_DISPATCHER")
                .antMatchers("/aseUser/dispatcher/**").hasAuthority("ROLE_DISPATCHER")
                .antMatchers("/pickupbox").hasAuthority("ROLE_DISPATCHER")
                .antMatchers("/dispatcher").hasAuthority("ROLE_DISPATCHER")
                .antMatchers("/deliverer").hasAnyAuthority("ROLE_DISPATCHER", "ROLE_DELIVERER")
                .antMatchers("/deliverer/**").hasAnyAuthority("ROLE_DISPATCHER", "ROLE_DELIVERER")
                .antMatchers("/customer").hasAnyAuthority("ROLE_DISPATCHER", "ROLE_CUSTOMER")
                .antMatchers("/customer/**").hasAnyAuthority("ROLE_DISPATCHER", "ROLE_CUSTOMER")
                .antMatchers("/**").authenticated()

                // login

                .and()
                .httpBasic() // 3. Use Basic Authentication
                .and()
                .sessionManagement().disable();
    }

    @Override
    public void configure(AuthenticationManagerBuilder builder) throws Exception {
        builder.userDetailsService(mongoUserDetailsService);
    }

    @Override
    @Bean
    // Define an authentication manager to execute authentication services
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Bean
    // Define an instance of Bcrypt for hashing passwords
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /*
     * @Bean
     * CorsConfigurationSource corsConfigurationSource() {
     * UrlBasedCorsConfigurationSource source = new
     * UrlBasedCorsConfigurationSource();
     * source.registerCorsConfiguration("/**", new
     * CorsConfiguration().applyPermitDefaultValues());
     * source.
     * return source;
     * }
     */

    /*
     * @Bean
     * public WebMvcConfigurer corsConfigurer() {
     * return new WebMvcConfigurer() {
     * 
     * @Override
     * public void addCorsMappings(CorsRegistry registry) {
     * registry.addMapping("/greeting-javaconfig").allowedOrigins(
     * "http://localhost:8080");
     * }
     * };
     * }
     */

}
