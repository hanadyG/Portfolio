import json
f = open('Box_id.json')
data = json.load(f)
Raspberry_ID=data['ID'] #we only need the id the rest is handled in the backend
f.close()
adress_deployment="http://localhost:" #this change depending on the deployment, it never is localhost, you have to put the idpv4 adress of the pc where u run
try:
  while True:
    print("Hold a tag near the reader")
    id='plo'
    getpath=adress_deployment+":8080/tags/"+Raspberry_ID+"/"+str(id) # prepare request
    print(getpath)
    role="Customer" # either Customer or Deliverer or Raspberry not found! or Unauthorized
    if role=="Raspberry not found!":
      print('check the Box_id.json')
    elif role=="Customer" or role=='Deliverer':
      print('green')
      u=0
      for i in range(10):
        u+=1
      if(u>0):
        print('red')
      if(role=="Customer"):
        giveinfocostumer=adress_deployment+":8080/tags/"+"customer/"+Raspberry_ID
        print(giveinfocostumer)
      else:
        giveinfodeliverer=adress_deployment+":8080/tags/"+"deliverer/"+Raspberry_ID
        print(giveinfodeliverer)  #this will change delivery status and send mail

    else: #Unauthorized
        print('red'+'Unauthorized')
except KeyboardInterrupt:
  print('oups')