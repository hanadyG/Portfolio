import json
from time import sleep
import sys
from mfrc522 import SimpleMFRC522
import RPi.GPIO as GPIO
from time import sleep
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
PIN_GREEN=14
PIN_RED=15
PIN_LDR=18
GPIO.setup(PIN_RED,GPIO.OUT,initial=GPIO.LOW)
GPIO.setup(PIN_GREEN,GPIO.OUT,initial=GPIO.LOW)
GPIO.setup(PIN_LDR, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
f = open('user_ids.json')
data = json.load(f)
reader = SimpleMFRC522()
try:
  while True:
    print("Hold a tag near the reader")
    id, text = reader.read()
    print("ID: %s\nText: %s" % (id,text))
    here=False
    for id_data in data:
      if(str(id_data['id'])==str(id)):
        here=True
    if here==True:  # since we don't communicate
      print("I AM GREEN")
      GPIO.output(PIN_GREEN,GPIO.HIGH)
      sleep(2)
      GPIO.output(PIN_GREEN,GPIO.LOW)
      sleep(10) # 10 sec to close the box
      u=0
      for i in range(10):
        u+=GPIO.input(PIN_LDR)
        sleep(0.1)
      if(u>0):
        print("I AM RED, close the box properly")
        GPIO.output(PIN_RED,GPIO.HIGH)
        sleep(2)
        GPIO.output(PIN_RED,GPIO.LOW)
    else:
      print("I AM RED, wrong RFID")
      GPIO.output(PIN_RED,GPIO.HIGH)
      sleep(2)
      GPIO.output(PIN_RED,GPIO.LOW)
except KeyboardInterrupt:
  GPIO.cleanup()
