import json  #in case we have the database in json
from time import sleep #sleep(1) = 1 second wait
import sys
from mfrc522 import SimpleMFRC522 #library for RFID-RC522
import RPi.GPIO as GPIO # GPIO pins on the raspberry
import requests # To do http requests
GPIO.setmode(GPIO.BCM) #way to refer for the pins
GPIO.setwarnings(False) #disable warning
PIN_GREEN=14 #Pin position in which we put the leg that turn the led green
PIN_RED=15 #Pin position in which we put the leg that turn the led red
PIN_LDR=18 #Pin position in which we put the leg of the LDR
GPIO.setup(PIN_RED,GPIO.OUT,initial=GPIO.LOW) #Settings to output for led
GPIO.setup(PIN_GREEN,GPIO.OUT,initial=GPIO.LOW) #Settings to output for led
GPIO.setup(PIN_LDR, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) #Settings to input for ldr
# Opening JSON file that contains the value of raspberrypi
f = open('Box_id.json')
data = json.load(f)
Raspberry_ID=data['ID'] #we only need the id the rest is handled in the backend
f.close()
adress_deployment="http://localhost:" #this change depending on the deployment, it never is localhost, you have to put the idpv4 adress of the pc where u run
reader = SimpleMFRC522() #The reader RFID-RC522
try:
  while True:
    print("Hold a tag near the reader")
    id, text = reader.read() #read rfid tag, memorize the id
    print("ID: %s\nText: %s" % (id,text))
    getpath=adress_deployment+":8080/tags/"+Raspberry_ID+"/"+str(id) # prepare request
    r=requests.get(getpath)
    role=r.text # either Customer or Deliverer or Raspberry not found! or Unauthorized
    if role=="Raspberry not found!":
      print('check the Box_id.json')
    elif role=="Customer" or role=='Deliverer':
      GPIO.output(PIN_GREEN,GPIO.HIGH) #he can open, the pin turns the led green
      sleep(2) #stays lit up for 1 sec
      GPIO.output(PIN_GREEN,GPIO.LOW) #turn the led off
      sleep(10) # we have 10 sec to close the box
      u=0
      for i in range(10):
        u+=GPIO.input(PIN_LDR) #u is strictly positive if the LDR has any light on it, since one try is sometime not enough, we do the test 10 times in one second
        sleep(0.1)
      if(u>0):
        GPIO.output(PIN_RED,GPIO.HIGH) #he didn't close the box properly, the pin turns the led red
        sleep(2)
        GPIO.output(PIN_RED,GPIO.LOW) #turn the led off

    else: #Unauthorized
      GPIO.output(15,GPIO.HIGH) #he can't open, the pin turns the led red
      sleep(2)
      GPIO.output(15,GPIO.LOW) #turn the led off
except KeyboardInterrupt:
  GPIO.cleanup()