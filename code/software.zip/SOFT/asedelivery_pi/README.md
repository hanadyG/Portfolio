# asedelivery_pi

What is inside the raspberry, there is 3 version now: one without communication, one with get request and one with both get and post requests.