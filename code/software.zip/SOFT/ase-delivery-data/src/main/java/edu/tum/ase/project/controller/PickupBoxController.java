package edu.tum.ase.project.controller;

import edu.tum.ase.project.model.Customer;
import edu.tum.ase.project.model.Dispatcher;
import edu.tum.ase.project.model.PickupBox;
import edu.tum.ase.project.repository.DispatcherRepository;
import edu.tum.ase.project.service.CustomerService;
import edu.tum.ase.project.service.DispatcherService;
import edu.tum.ase.project.service.PickupBoxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/pickupbox")
public class PickupBoxController {

    @Autowired
    PickupBoxService pickupBoxService;

    @GetMapping("")
    public ResponseEntity<List<PickupBox>> getAllPickupBoxes() {
        try {
            List<PickupBox> pickupBoxes = pickupBoxService.getAllPickupBoxes();

            if (pickupBoxes.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(pickupBoxes, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /*@GetMapping("/{id}/{tag}")
    public ResponseEntity<Boolean> getPickupBoxAuth(@PathVariable("id") String id, @PathVariable("tag") String tag) {
        Optional<PickupBox> pickupBoxData = pickupBoxService.findById(id);
        System.out.println("Print pickupbox");
        if (pickupBoxData.isPresent()) {
            PickupBox pickupBox = pickupBoxData.get();
            return new ResponseEntity<>(pickupBox.getCustomerTag() == tag || pickupBox.getDelivererTag() == tag, HttpStatus.OK);
        }
        else {
            return  new ResponseEntity<>(false, HttpStatus.NOT_FOUND);
        }
    } */

    @PostMapping("")
    public ResponseEntity<PickupBox> createPickupBox(@RequestBody PickupBox pickupBox) {
        try {
            PickupBox createdPickupBox = pickupBoxService.createPickupBox(new PickupBox(pickupBox.getName(), pickupBox.getAddress()));
            return new ResponseEntity<>(createdPickupBox, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<PickupBox> updatePickupBox(@PathVariable("id") String id, @RequestBody PickupBox newPickupBox) {
        Optional<PickupBox> pickupBoxData = pickupBoxService.findById(id);

        if (pickupBoxData.isPresent()) {
            PickupBox pickupBox = pickupBoxData.get();
            pickupBox.setName(newPickupBox.getName());
            pickupBox.setAddress(newPickupBox.getAddress());
            pickupBox.setDeliverer(pickupBox.getDeliverer());
            pickupBox.setCustomer(pickupBox.getCustomer());
            pickupBox.setDeliveries(pickupBox.getDeliveries());
            return new ResponseEntity<>(pickupBoxService.update(pickupBox), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping ("/{id}")
    public ResponseEntity<PickupBox> deletePickupBox(@PathVariable("id") String id) {
        try {
            pickupBoxService.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

