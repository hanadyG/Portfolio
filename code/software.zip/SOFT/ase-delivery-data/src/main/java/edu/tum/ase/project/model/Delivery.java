package edu.tum.ase.project.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.mongodb.lang.NonNull;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")

@Document(collection = "deliveries")
public class Delivery {
    @Id
    protected String id;

    public String status;

    @Indexed(unique = true)
    @NonNull
    public String trackingCode;


    @DBRef
    private Customer customer;

    @DBRef
    private Deliverer deliverer;

    @DBRef
    private PickupBox pickupBox;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @NonNull
    public String getTrackingCode() {
        return trackingCode;
    }

    public void setTrackingCode(@NonNull String trackingCode) {
        this.trackingCode = trackingCode;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setDeliverer(Deliverer deliverer) {
        this.deliverer = deliverer;
    }

    public Delivery(String status, String trackingCode, Customer customer, Deliverer deliverer, PickupBox pickupBox) {
        this.status = status;
        this.trackingCode = trackingCode;
        this.customer = customer;
        this.deliverer = deliverer;
        this.pickupBox = pickupBox;
    }

    public Delivery() {
    }

    public String getId() {
        return id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Deliverer getDeliverer() {
        return deliverer;
    }

    public PickupBox getPickupBox() {
        return pickupBox;
    }

    public void setPickupBox(PickupBox pickupBox) {
        this.pickupBox = pickupBox;
    }
}
