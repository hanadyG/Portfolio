package edu.tum.ase.project.controller;

import edu.tum.ase.project.model.Customer;
import edu.tum.ase.project.model.Delivery;
import edu.tum.ase.project.model.Dispatcher;
import edu.tum.ase.project.model.PickupBox;
import edu.tum.ase.project.repository.DispatcherRepository;
import edu.tum.ase.project.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/tags")
public class TagsController {

    @Autowired
    PickupBoxService pickupBoxService;

    @Autowired
    DeliveryService deliveryService;

    @Autowired
    MailService mailService;

    @GetMapping("/{id}/{tag}")
    public ResponseEntity<String> getPickupBoxAuth(@PathVariable("id") String id, @PathVariable("tag") String tag) {
        Optional<PickupBox> pickupBoxData = pickupBoxService.findById(id);
        System.out.println("Print pickupbox");
        if (pickupBoxData.isPresent()) {
            PickupBox pickupBox = pickupBoxData.get();
            if(pickupBox.getCustomerTag().equals(tag)){
                return new ResponseEntity<>("Customer", HttpStatus.OK);
            } else if(pickupBox.getDelivererTag().equals(tag)) {
                return new ResponseEntity<>("Deliverer", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Unauthorized", HttpStatus.OK);
            }
            //return new ResponseEntity<>(pickupBox.getCustomerTag() == tag || pickupBox.getDelivererTag() == tag, HttpStatus.OK);
        }
        else {
            return  new ResponseEntity<>("Raspberry not found!", HttpStatus.NOT_FOUND);
        }

        /*@PutMapping("/{id}/{role}/{tag}")
        public ResponseEntity<PickupBox> createPickupBox(@PathVariable("id") String id, @PathVariable("role") String role, @PathVariable("tag") String tag) {
            if(role == "customer"){
                Optional<PickupBox> pickupBoxData = pickupBoxService.findById(id);
                PickupBox pickupBox = pickupBoxData.get();
                String mail = pickupBox.getCustomerEmail();
                mailService.sendMail(mail, "Hello, the pickup was successful.");
            }
            if(role == "deliverer"){
                Optional<PickupBox> pickupBoxData = pickupBoxService.findById(id);
                PickupBox pickupBox = pickupBoxData.get();
                pickupBox.getCustomerEmail();
            }
        }*/
    }
    @GetMapping("/customer/e/{id}")
    public ResponseEntity<Boolean> UpdateStatusOfDelivery(@PathVariable("id") String id)
    {
        try
        {
            Optional<PickupBox> pickupBoxData = pickupBoxService.findById(id);
            PickupBox pickupBox = pickupBoxData.get();
            if(pickupBox.getDeliveries().size() > 0)
            {
                Set<Delivery> deliveries = pickupBox.getDeliveries();
                for(Delivery delivery : deliveries)
                {
                    pickupBox.removeDelivery(delivery);
                    delivery.setStatus("picked-up");
                    deliveryService.update(delivery);

                }
                mailService.sendMail(pickupBox.getCustomerEmail(), "Your delivery was successfully picked-up from: " + pickupBox.getAddress(), "update status on your delivery");
                pickupBox.setCustomer(null);
                pickupBox.setDeliverer(null);
                pickupBoxService.update(pickupBox);
                return new ResponseEntity<>(true, HttpStatus.OK);
            }
            else
            {
                return new ResponseEntity<>(false, HttpStatus.NO_CONTENT);
            }

        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return new ResponseEntity<>(false, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/deliverer/e/{id}")
    public ResponseEntity<Boolean> UpdateStatusOfDeliveryForCustomer(@PathVariable("id") String id)
    {
        try
        {
            Optional<PickupBox> pickupBoxData = pickupBoxService.findById(id);
            PickupBox pickupBox = pickupBoxData.get();
            if(pickupBox.getDeliveries().size() > 0)
            {
                Set<Delivery> deliveries = pickupBox.getDeliveries();
                for(Delivery delivery : deliveries)
                {
                    delivery.setStatus("delivered");
                    deliveryService.update(delivery);
                }
                mailService.sendMail(pickupBox.getCustomerEmail(), "Your delivery delivered to pickup-box. You can get it from: " + pickupBox.getAddress(), "update status on your delivery");
                return new ResponseEntity<>(true, HttpStatus.OK);
                /* TODO: send an email to customer */

            }
            else
            {
                return new ResponseEntity<>(false, HttpStatus.NO_CONTENT);
            }

        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return new ResponseEntity<>(false, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }




}

