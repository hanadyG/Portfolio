package edu.tum.ase.project.repository;

import edu.tum.ase.project.model.Delivery;
import edu.tum.ase.project.model.PickupBox;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PickupBoxRepository extends MongoRepository<PickupBox, String> {
    PickupBox findByName(String name);
}
