package edu.tum.ase.project.model;

import com.mongodb.lang.NonNull;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "baseusers")
public abstract class BaseUser
{

    /*@Id
    protected String id;*/

    @Indexed(unique = true)
    @NonNull
    protected String email;

    //...
    //perform an action that must have a different behaviour for each user type
    public abstract String getEmail();
    public abstract void setEmail(String email);
    public abstract String getId();
}
