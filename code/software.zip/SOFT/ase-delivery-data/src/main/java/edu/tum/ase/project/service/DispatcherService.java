package edu.tum.ase.project.service;

import edu.tum.ase.project.model.*;
import edu.tum.ase.project.repository.CustomerRepository;
import edu.tum.ase.project.repository.DelivererRepository;
import edu.tum.ase.project.repository.DeliveryRepository;
import edu.tum.ase.project.repository.DispatcherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DispatcherService {
    @Autowired
    CustomerService customerService;

    @Autowired
    DelivererService delivererService;

    @Autowired
    DeliveryService deliveryService;

    @Autowired
    PickupBoxService pickupBoxService;

    @Autowired
    DispatcherRepository dispatcherRepository;

    public Dispatcher createDispatcher(Dispatcher dispatcher) {
        Dispatcher createdDispatcher = dispatcherRepository.insert(dispatcher);
        return createdDispatcher;
    }

    public void deleteDispatcher(Dispatcher dispatcher) {
        dispatcherRepository.delete(dispatcher);
    }

    public List<Dispatcher> getAllDispatchers() {
        List<Dispatcher> dispatchers = dispatcherRepository.findAll();
        return dispatchers;
    }

    public Optional<Dispatcher> findById(String id) {
        return dispatcherRepository.findById(id);
    }

    public Dispatcher update(Dispatcher dispatcher) {
        return dispatcherRepository.save(dispatcher);
    }

    public void deleteById(String id) {
        dispatcherRepository.deleteById(id);
    }

    public Dispatcher findByEmail(String mail) {
        Dispatcher dis = dispatcherRepository.findByEmail(mail);
        return dis;
    }
}
