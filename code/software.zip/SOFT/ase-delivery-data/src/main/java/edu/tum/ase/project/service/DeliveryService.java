package edu.tum.ase.project.service;

import edu.tum.ase.project.model.Customer;
import edu.tum.ase.project.model.Deliverer;
import edu.tum.ase.project.model.Delivery;
import edu.tum.ase.project.repository.CustomerRepository;
import edu.tum.ase.project.repository.DelivererRepository;
import edu.tum.ase.project.repository.DeliveryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DeliveryService {
    @Autowired
    private DeliveryRepository deliveryRepository;
    @Autowired
    private CustomerService customerService;
    @Autowired
    private DelivererService delivererService;
    @Autowired
    private PickupBoxService pickupBoxService;

    public Delivery createDelivery(Delivery delivery) {
        Delivery createdDelivery = deliveryRepository.insert(delivery);
        if (createdDelivery.getCustomer() != null) {
            customerService.addDelivery(createdDelivery.getCustomer(), createdDelivery);
        }
        if (createdDelivery.getDeliverer() != null) {
            delivererService.addDelivery(createdDelivery.getDeliverer(), createdDelivery);
        }
        if (createdDelivery.getPickupBox() != null) {
            pickupBoxService.addDelivery(createdDelivery.getPickupBox(), createdDelivery);

            if (createdDelivery.getCustomer() != null) {
                pickupBoxService.setCustomer(createdDelivery.getPickupBox(), createdDelivery.getCustomer());
            }
            if (createdDelivery.getDeliverer() != null) {
                pickupBoxService.addDeliverer(createdDelivery.getPickupBox(), createdDelivery.getDeliverer());
            }
        }
        return createdDelivery;
    }

    public void deleteDelivery(Delivery delivery) {
        if (delivery.getCustomer() != null) {
            customerService.removeDelivery(delivery.getCustomer(), delivery);
        }
        if (delivery.getDeliverer() != null) {
            delivererService.removeDelivery(delivery.getDeliverer(), delivery);
        }
        if (delivery.getPickupBox() != null) {
            pickupBoxService.removeDelivery(delivery.getPickupBox(), delivery);
        }
        deliveryRepository.delete(delivery);
    }

    public Delivery findByTrackingCode(String trackingCode) {
        Delivery delivery = deliveryRepository.findByTrackingCode(trackingCode);
        return delivery;
    }

    public List<Delivery> getAllDeliveries() {
        List<Delivery> deliveries = deliveryRepository.findAll();
        return deliveries;
    }

    public Optional<Delivery> findById(String id) {
        return deliveryRepository.findById(id);
    }

    public Delivery update(Delivery delivery) {
        delivererService.deleteById(delivery.getId());
        return deliveryRepository.save(delivery);
    }

    public void deleteById(String id) {
        deliveryRepository.deleteById(id);
    }

    public List<Delivery> findByCustomer(Customer customer) {
        return deliveryRepository.findByCustomer(customer);
    }

    public List<Delivery> findByDeliverer(Deliverer deliverer) {
        return deliveryRepository.findByDeliverer(deliverer);
    }
}
