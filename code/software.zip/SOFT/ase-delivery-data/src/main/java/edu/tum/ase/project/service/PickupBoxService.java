package edu.tum.ase.project.service;

import edu.tum.ase.project.model.Customer;
import edu.tum.ase.project.model.Deliverer;
import edu.tum.ase.project.model.Delivery;
import edu.tum.ase.project.model.PickupBox;
import edu.tum.ase.project.repository.CustomerRepository;
import edu.tum.ase.project.repository.PickupBoxRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PickupBoxService {
    @Autowired
    private PickupBoxRepository pickupBoxRepository;

    public PickupBox createPickupBox(PickupBox pickupBox) {
        PickupBox createdPickupBox = pickupBoxRepository.insert(pickupBox);
        return createdPickupBox;
    }
    public void deletePickupBox(PickupBox pickupBox) {
        pickupBoxRepository.delete(pickupBox);
    }

    public void addDelivery(PickupBox pickupBox, Delivery delivery) {
        pickupBox.addDelivery(delivery);
        pickupBoxRepository.save(pickupBox);
    }

    public void removeDelivery(PickupBox pickupBox, Delivery delivery) {
        pickupBox.removeDelivery(delivery);
        pickupBoxRepository.save(pickupBox);
    }

    public void addDeliverer(PickupBox pickupBox, Deliverer deliverer) {
        pickupBox.setDeliverer(deliverer);
        pickupBoxRepository.save(pickupBox);
    }

    public void removeDeliverer(PickupBox pickupBox, Deliverer deliverer) {
        pickupBox.setDeliverer(null);
        pickupBoxRepository.save(pickupBox);
    }

    public void setCustomer(PickupBox pickupBox, Customer customer) {
        pickupBox.setCustomer(customer);
        pickupBoxRepository.save(pickupBox);
    }

    public Deliverer setDeliverer(PickupBox pickupBox) {
        return pickupBox.getDeliverer();
    }

    public PickupBox findByName(String name) {
        PickupBox pickupBox = pickupBoxRepository.findByName(name);
        return pickupBox;
    }

    public List<PickupBox> getAllPickupBoxes() {
        List<PickupBox> pickupBoxes = pickupBoxRepository.findAll();
        return pickupBoxes;
    }

    public Optional<PickupBox> findById(String id) {
        return pickupBoxRepository.findById(id);
    }

    public PickupBox update(PickupBox pickupBox) {
        return pickupBoxRepository.save(pickupBox);
    }

    public void deleteById(String id) {
        pickupBoxRepository.deleteById(id);
    }
}
