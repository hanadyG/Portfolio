package edu.tum.ase.project.controller;

import edu.tum.ase.project.model.Customer;
import edu.tum.ase.project.model.Delivery;
import edu.tum.ase.project.service.AuthService;
import edu.tum.ase.project.service.CustomerService;
import edu.tum.ase.project.service.DeliveryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @Autowired
    DeliveryService deliveryService;

    @Autowired
    AuthService authService;

    @GetMapping("")
    public ResponseEntity<List<Customer>> getAllCustomers(HttpServletRequest request) {
        try {
            List<Customer> customers = new ArrayList<>();

            String[] details = authService.getAuthentication(request);
            System.out.println("username: " + details[0]);
            System.out.println("Role: " + details[1]);
            if (details[1].contains("ROLE_CUSTOMER")) {
                customers.add(customerService.findByEmail(details[0]));
            } else if (details[1].contains("ROLE_DISPATCHER")) {

                customers = customerService.getAllCustomers();
            }

            if (customers.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(customers, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("deliveries/{id}")
    public ResponseEntity<Set<Delivery>> getDeliveriesOfCustomer(@PathVariable("id") String id) {
        List<Delivery> deliveries = deliveryService.getAllDeliveries();
        try {
            Set<Delivery> deliveriesToBeSent = new HashSet<Delivery>();
            for (Delivery delivery : deliveries) {
                if (delivery.getCustomer().getId().equals(id)) {
                    deliveriesToBeSent.add(delivery);
                }
            }
            if (deliveriesToBeSent.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(deliveriesToBeSent, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        /*
         * Optional<Customer> customerData = customerService.findById(id);
         * try {
         * Customer customer = customerData.get();
         * Set<Delivery> deliveries = customer.getDeliveries();
         * 
         * if (deliveries.isEmpty()) {
         * return new ResponseEntity<>(HttpStatus.NO_CONTENT);
         * }
         * 
         * return new ResponseEntity<>(deliveries, HttpStatus.OK);
         * } catch (Exception e) {
         * return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
         * }
         */
    }

    @PostMapping("")
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        try {

            if (customerService.findByEmail(customer.getEmail()) == null) {
                Customer createdCustomer = customerService.createCustomer(new Customer(customer.getEmail(), customer.getTag()));
                return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(null, HttpStatus.UNAUTHORIZED);
            }

        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable("id") String id, @RequestBody Customer newCustomer) {
        Optional<Customer> customerData = customerService.findById(id);

        if (customerData.isPresent()) {
            Customer customer = customerData.get();
            customer.setEmail(newCustomer.getEmail());
            return new ResponseEntity<>(customerService.update(customer), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Customer> deleteCustomer(@PathVariable("id") String id) {
        try {
            customerService.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
