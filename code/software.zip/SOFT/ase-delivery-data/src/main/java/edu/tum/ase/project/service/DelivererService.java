package edu.tum.ase.project.service;

import edu.tum.ase.project.model.Customer;
import edu.tum.ase.project.model.Deliverer;
import edu.tum.ase.project.model.Delivery;
import edu.tum.ase.project.repository.CustomerRepository;
import edu.tum.ase.project.repository.DelivererRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DelivererService {
    @Autowired
    private DelivererRepository delivererRepository;

    public Deliverer createDeliverer(Deliverer deliverer) {
        Deliverer createdDeliverer = delivererRepository.insert(deliverer);
        return createdDeliverer;
    }

    public Deliverer findByEmail(String email) {
        Deliverer deliverer = delivererRepository.findByEmail(email);
        return deliverer;
    }

    public List<Deliverer> getAllDeliverers() {
        List<Deliverer> deliverers = delivererRepository.findAll();
        return deliverers;
    }

    public void addDelivery(Deliverer deliverer, Delivery delivery) {
        deliverer.addDelivery(delivery);
        delivererRepository.save(deliverer);
    }

    public void removeDelivery(Deliverer deliverer, Delivery delivery) {
        deliverer.removeDelivery(delivery);
        delivererRepository.save(deliverer);
    }

    public Optional<Deliverer> findById(String id) {
        return delivererRepository.findById(id);
    }

    public Deliverer update(Deliverer deliverer) {
        return delivererRepository.save(deliverer);
    }

    public void deleteById(String id) {
        delivererRepository.deleteById(id);
    }
}
