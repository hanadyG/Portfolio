package edu.tum.ase.project.controller;

import edu.tum.ase.project.model.Deliverer;
import edu.tum.ase.project.model.Delivery;
import edu.tum.ase.project.service.DelivererService;
import edu.tum.ase.project.service.DeliveryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import edu.tum.ase.project.service.AuthService;

import java.util.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/deliverer")
public class DelivererController {

    @Autowired
    DelivererService delivererService;

    @Autowired
    DeliveryService deliveryService;

    @Autowired
    AuthService authService;

    @GetMapping("")
    public ResponseEntity<List<Deliverer>> getAllDeliverers(HttpServletRequest request) {
        try {
            List<Deliverer> deliverers = new ArrayList<>();
            String[] details = authService.getAuthentication(request);
            System.out.println("username: " + details[0]);
            System.out.println("Role: " + details[1]);
            if (details[1].contains("ROLE_DELIVERER")) {
                deliverers.add(delivererService.findByEmail(details[0]));
            } else if (details[1].contains("ROLE_DISPATCHER")) {
                deliverers = delivererService.getAllDeliverers();
            }
            if (deliverers.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(deliverers, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("deliveries/{id}")
    public ResponseEntity<Set<Delivery>> getDeliveriesOfDeliverer(@PathVariable("id") String id) {
        List<Delivery> deliveries = deliveryService.getAllDeliveries();
        try {
            Set<Delivery> deliveriesToBeSent = new HashSet<Delivery>();
            for (Delivery delivery : deliveries) {
                if (delivery.getDeliverer().getId().equals(id)) {
                    deliveriesToBeSent.add(delivery);
                }
            }
            if (deliveriesToBeSent.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(deliveriesToBeSent, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        /*
         * Optional<Deliverer> delivererData = delivererService.findById(id);
         * try {
         * Deliverer deliverer = delivererData.get();
         * Set<Delivery> deliveries = deliverer.getDeliveries();
         * 
         * if (deliveries.isEmpty()) {
         * return new ResponseEntity<>(HttpStatus.NO_CONTENT);
         * }
         * 
         * return new ResponseEntity<>(deliveries, HttpStatus.OK);
         * } catch (Exception e) {
         * return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
         * }
         */
    }

    @PostMapping("")
    public ResponseEntity<Deliverer> createDeliverer(@RequestBody Deliverer deliverer) {
        if (delivererService.findByEmail(deliverer.getEmail()) == null) {
            Deliverer createdDeliverer = delivererService.createDeliverer(new Deliverer(deliverer.getEmail(), deliverer.getTag()));
            return new ResponseEntity<>(createdDeliverer, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(null, HttpStatus.UNAUTHORIZED);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Deliverer> updateDeliverer(@PathVariable("id") String id,
            @RequestBody Deliverer newDeliverer) {
        Optional<Deliverer> delivererData = delivererService.findById(id);

        if (delivererData.isPresent()) {
            Deliverer deliverer = delivererData.get();
            deliverer.setEmail(newDeliverer.getEmail());
            deliverer.setDeliveries(newDeliverer.getDeliveries());
            return new ResponseEntity<>(delivererService.update(deliverer), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update_delivery/{id}")
    public ResponseEntity<Delivery> updateDelivery(@PathVariable("id") String id,
            @RequestBody Map<String, String> payload) {
        Optional<Delivery> deliveryData = deliveryService.findById(id);

        if (deliveryData.isPresent()) {
            Delivery delivery = deliveryData.get();
            delivery.setStatus(payload.get("status"));
            return new ResponseEntity<>(deliveryService.update(delivery), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Deliverer> deleteDeliverer(@PathVariable("id") String id) {
        try {
            delivererService.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
