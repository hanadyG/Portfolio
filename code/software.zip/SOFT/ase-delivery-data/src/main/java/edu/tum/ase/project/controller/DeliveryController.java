package edu.tum.ase.project.controller;

import edu.tum.ase.project.model.Customer;
import edu.tum.ase.project.model.Deliverer;
import edu.tum.ase.project.model.Delivery;
import edu.tum.ase.project.model.Dispatcher;
import edu.tum.ase.project.repository.DispatcherRepository;
import edu.tum.ase.project.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.userdetails.UserDetails;
import javax.servlet.http.HttpServletRequest;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/delivery")
public class DeliveryController {

    @Autowired
    DeliveryService deliveryService;

    @Autowired
    CustomerService customerService;

    @Autowired
    MailService mailService;

    @Autowired
    DelivererService delivererService;

    @Autowired
    PickupBoxService pickupBoxService;

    @Autowired
    AuthService authService;

    @GetMapping("")
    public ResponseEntity<List<Delivery>> getAllDeliveries(HttpServletRequest request) {
        try {
            List<Delivery> deliveries;
            deliveries = deliveryService.getAllDeliveries();

            String[] details = authService.getAuthentication(request);
            System.out.println("username: " + details[0]);
            System.out.println("Role: " + details[1]);
            if (details[1].contains("ROLE_DELIVERER")) {
                deliveries = deliveryService.findByDeliverer(delivererService.findByEmail(details[0]));
            } else if (details[1].contains("ROLE_CUSTOMER")) {
                deliveries = deliveryService.findByCustomer(customerService.findByEmail(details[0]));
            }
            if (deliveries.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(deliveries, HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("")
    public ResponseEntity<Delivery> createDelivery(@RequestBody Delivery delivery) {
        try {
            Delivery d = new Delivery(delivery.getStatus(),
                    delivery.getTrackingCode(),
                    customerService.findById(delivery.getCustomer().getId()).get(),
                    delivererService.findById(delivery.getDeliverer().getId()).get(),
                    pickupBoxService.findById(delivery.getPickupBox().getId()).get());

            Delivery createdDelivery = deliveryService.createDelivery(d);
            mailService.sendMail(customerService.findById(delivery.getCustomer().getId()).get().getEmail(),
                    "Hello, your delivery is created.", "Created Delivery");
            return new ResponseEntity<>(createdDelivery, HttpStatus.CREATED);
        } catch (Exception e) {
            System.out.println("e.mes " + e.getMessage());
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Delivery> updateDelivery(@PathVariable("id") String id, @RequestBody Delivery newDelivery) {
        Optional<Delivery> deliveryData = deliveryService.findById(id);

        if (deliveryData.isPresent()) {
            Delivery delivery = deliveryData.get();
            delivery.setTrackingCode(newDelivery.getTrackingCode());
            delivery.setDeliverer(newDelivery.getDeliverer());
            delivery.setPickupBox(newDelivery.getPickupBox());
            delivery.setCustomer(newDelivery.getCustomer());
            delivery.setStatus(newDelivery.getStatus());
            return new ResponseEntity<>(deliveryService.update(delivery), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Delivery> deleteDelivery(@PathVariable("id") String id) {
        try {
            deliveryService.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
