package edu.tum.ase.project.repository;

import edu.tum.ase.project.model.Delivery;
import edu.tum.ase.project.model.Dispatcher;
import edu.tum.ase.project.model.PickupBox;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DispatcherRepository extends MongoRepository<Dispatcher, String> {
    Dispatcher findByEmail(String email);
}
