package edu.tum.ase.project.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.HashSet;
import java.util.Set;

@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
@Document(collection = "customers")
public class Customer extends BaseUser {
    @Id
    protected String id;
    // @JsonManagedReference(value="delivery-customer")
    @DBRef
    Set<Delivery> deliveries;

    public String tag;

    public Customer(String email, String tag) {
        this.email = email;
        deliveries = new HashSet<Delivery>();
        this.tag = tag;
    }

    public Customer() {
    }

    @Override
    public String getEmail() {
        return this.email;
    }

    @Override
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String getId() {
        return this.id;
    }

    public void addDelivery(Delivery delivery) {
        this.deliveries.add(delivery);
    }

    public Set<Delivery> getDeliveries() {
        return this.deliveries;
    }

    public void removeDelivery(Delivery delivery) {
        this.deliveries.removeIf(d -> d.getId().equals(delivery.getId()));
    }

    public String getTag() {
        return this.tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
