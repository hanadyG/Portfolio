package edu.tum.ase.project.controller;

import edu.tum.ase.project.model.Dispatcher;
import edu.tum.ase.project.repository.DispatcherRepository;
import edu.tum.ase.project.service.AuthService;
import edu.tum.ase.project.service.DispatcherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/dispatcher")
public class DispatcherController {

    @Autowired
    DispatcherService dispatcherService;

    @Autowired
    AuthService authService;

    @GetMapping("")
    public ResponseEntity<List<Dispatcher>> getAllDispatchers(HttpServletRequest request) {
        try {
            List<Dispatcher> dispatchers = new ArrayList<>();

            String[] details = authService.getAuthentication(request);
            dispatchers.add(dispatcherService.findByEmail(details[0]));
            if (dispatchers.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(dispatchers, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("")
    public ResponseEntity<Dispatcher> createDispatcher(@RequestBody Dispatcher dispatcher) {
        if (dispatcherService.findByEmail(dispatcher.getEmail()) == null) {
            Dispatcher createdDispatcher = dispatcherService.createDispatcher(new Dispatcher(dispatcher.getEmail()));
            return new ResponseEntity<>(createdDispatcher, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(null, HttpStatus.UNAUTHORIZED);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Dispatcher> updateDispatcher(@PathVariable("id") String id,
            @RequestBody Dispatcher newDispatcher) {
        Optional<Dispatcher> dispatcherData = dispatcherService.findById(id);

        if (dispatcherData.isPresent()) {
            Dispatcher dispatcher = dispatcherData.get();
            dispatcher.setEmail(newDispatcher.getEmail());
            return new ResponseEntity<>(dispatcherService.update(dispatcher), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Dispatcher> deleteDispatcher(@PathVariable("id") String id) {
        try {
            dispatcherService.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
