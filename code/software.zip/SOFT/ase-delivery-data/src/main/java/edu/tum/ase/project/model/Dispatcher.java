package edu.tum.ase.project.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import edu.tum.ase.project.service.CustomerService;
import edu.tum.ase.project.service.DelivererService;
import edu.tum.ase.project.service.DeliveryService;
import edu.tum.ase.project.service.PickupBoxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.HashSet;

@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
@Document(collection = "dispatchers")
public class Dispatcher extends BaseUser{
    public Dispatcher(String email) {
        this.email = email;
    }
    @Id
    protected String id;
    public Dispatcher() {
    }

    @Override
    public String getEmail() {
        return email;
    }

    @Override
    public void setEmail(String email) {
        this.email = email ;
    }

    @Override
    public String getId() {
        return id;
    }
}
