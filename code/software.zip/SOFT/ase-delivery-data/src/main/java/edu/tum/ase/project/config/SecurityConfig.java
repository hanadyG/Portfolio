package edu.tum.ase.project.config;

//import org.springframework.context.annotation.Configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.csrf.*;

@Configuration
// @EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {


    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.cors()

                .and()
                .csrf().csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
                .and()
                /*
                 * .csrf().csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()).
                 * and()
                 */
                //.antMatcher("/dispatcher/**")
                .authorizeRequests()
                .antMatchers("/**").permitAll()

                /*
                 * .antMatchers("/dispatcher").hasAuthority("ROLE_DISPATCHER")
                 * .antMatchers("/pickupbox").hasAuthority("ROLE_DISPATCHER")
                 * .antMatchers("/pickupbox").hasAuthority("ROLE_DELIVERER")
                 * .antMatchers("/deliverer").hasAuthority("ROLE_DISPATCHER")
                 * .antMatchers("/deliverer").hasAuthority("ROLE_DELIVERER")
                 */

                // login

                .and()
                .sessionManagement().disable();
    }

    @Override
    @Bean
    // Define an authentication manager to execute authentication services
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Bean
    // Define an instance of Bcrypt for hashing passwords
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /*
     * @Bean
     * CorsConfigurationSource corsConfigurationSource() {
     * UrlBasedCorsConfigurationSource source = new
     * UrlBasedCorsConfigurationSource();
     * source.registerCorsConfiguration("/**", new
     * CorsConfiguration().applyPermitDefaultValues());
     * source.
     * return source;
     * }
     */

    /*
     * @Bean
     * public WebMvcConfigurer corsConfigurer() {
     * return new WebMvcConfigurer() {
     * 
     * @Override
     * public void addCorsMappings(CorsRegistry registry) {
     * registry.addMapping("/greeting-javaconfig").allowedOrigins(
     * "http://localhost:8080");
     * }
     * };
     * }
     */

}
