package edu.tum.ase.project.model;
/*
        Address,
        id,
        name
        unique printable name(id + name),
        Delivery_ids
        Customer_ids
        Deliverer_ids

 */


import com.fasterxml.jackson.annotation.*;
import com.mongodb.lang.NonNull;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.HashSet;
import java.util.Set;

//@JsonIgnoreProperties({ "deliveries", "customers", "deliverers" })
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
@Document(collection = "pickupboxes")
public class PickupBox {
    @Id
    protected String id;

    @Indexed(unique = true)
    @NonNull
    public String address;

    @Indexed(unique = true)
    @NonNull
    public String name;

    public Set<Delivery> getDeliveries() {
        return deliveries;
    }


    //@JsonManagedReference(value="delivery-pickupbox")
    @DBRef
    private Set<Delivery> deliveries;

    @DBRef
    private Customer customer;

    @DBRef
    private Deliverer deliverer;

    public String getCustomerTag() {
        if(customer == null)
            return null;
        return customer.getTag();
    }

    public String getDelivererTag() {
        if (deliverer == null)
            return null;
        return deliverer.getTag();
    }

    public void setDeliveries(Set<Delivery> deliveries) {
        this.deliveries = deliveries;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Customer getCustomer() {
        return customer;
    }

    public String getCustomerEmail() {
        if(customer == null)
            return null;
        return customer.getEmail();
    }

    public void setDeliverer(Deliverer deliverer) {
        this.deliverer = deliverer;
    }
    public Deliverer getDeliverer() {
        return this.deliverer;
    }

    public PickupBox(String name, String address) {
        this.name = name;
        this.address = address;
        deliveries = new HashSet<Delivery>();
    }

    public PickupBox() {

    }

    public String getId() {
        return id;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public void setName(@NonNull String name) {
        this.name = name;
    }

    @NonNull
    public String getAddress() {
        return address;
    }

    public void setAddress(@NonNull String address) {
        this.address = address;
    }

    public void addDelivery(Delivery delivery) {
        this.deliveries.add(delivery);
    }

    public void removeDelivery(Delivery delivery) {
        this.deliveries.removeIf(d -> d.getId().equals(delivery.getId()));
    }
}
