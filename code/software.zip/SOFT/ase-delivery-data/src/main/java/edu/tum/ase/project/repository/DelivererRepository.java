package edu.tum.ase.project.repository;

import edu.tum.ase.project.model.Customer;
import edu.tum.ase.project.model.Deliverer;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DelivererRepository extends MongoRepository<Deliverer, String> {
    Deliverer findByEmail(String email);
}
