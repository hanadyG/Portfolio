package edu.tum.ase.project.repository;

import edu.tum.ase.project.model.Customer;
import edu.tum.ase.project.model.Deliverer;
import edu.tum.ase.project.model.Delivery;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface DeliveryRepository extends MongoRepository<Delivery, String> {
    Delivery findByTrackingCode(String trackingCode);

    List<Delivery> findByCustomer(Customer customer);

    List<Delivery> findByDeliverer(Deliverer deliverer);
}
