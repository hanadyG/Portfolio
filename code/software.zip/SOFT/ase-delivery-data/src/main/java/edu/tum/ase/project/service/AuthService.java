package edu.tum.ase.project.service;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.reactive.function.client.WebClient;
import javax.servlet.http.Cookie;
import reactor.core.publisher.Mono;

@RestController
public class AuthService {
    public String[] getAuthentication(HttpServletRequest request) {
        String jwt = null;
        String xsrf = null;
        String session = null;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                if (cookies[i].getName().equals("jwt")) {
                    jwt = cookies[i].getValue();
                }
                if (cookies[i].getName().equals("XSRF-TOKEN")) {
                    xsrf = cookies[i].getValue();
                }
                if (cookies[i].getName().equals("JSESSIONID")) {
                    session = cookies[i].getValue();
                }
            }
        }

        WebClient client = WebClient.create("http://ase-delivery-auth:8081");
        try {
            ResponseEntity<String> res = client.get().cookie("jwt", jwt).cookie("XSRF-TOKEN", xsrf)
                    .cookie("JSESSIONID", session).retrieve()
                    .onStatus(status -> status.value() == 401, clientResponse -> Mono.error(new Exception()))
                    .toEntity(String.class)
                    .block();
            System.out.println(res.getBody());
            String[] arr = res.getBody().split(":");
            return arr;
        } catch (Exception e) {
            return null;
        }

    }
}
