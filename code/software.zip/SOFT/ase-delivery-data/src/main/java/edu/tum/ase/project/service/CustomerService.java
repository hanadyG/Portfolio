package edu.tum.ase.project.service;

import edu.tum.ase.project.model.Customer;
import edu.tum.ase.project.model.Delivery;
import edu.tum.ase.project.model.Dispatcher;
import edu.tum.ase.project.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    public Customer createCustomer(Customer customer) {
        Customer createdCustomer = customerRepository.insert(customer);
        return createdCustomer;
    }
    public void deleteCustomer(Customer customer) {
        customerRepository.delete(customer);
    }

    public void addDelivery(Customer customer, Delivery delivery) {
       customer.addDelivery(delivery);
       customerRepository.save(customer);
    }

    public void removeDelivery(Customer customer, Delivery delivery) {
        customer.removeDelivery(delivery);
        customerRepository.save(customer);
    }

    public Customer findByEmail(String email) {
        Customer customer = customerRepository.findByEmail(email);
        return customer;
    }

    public List<Customer> getAllCustomers() {
        List<Customer> customers = customerRepository.findAll();
        return customers;
    }

    public Optional<Customer> findById(String id) {
        return customerRepository.findById(id);
    }

    public Customer update(Customer customer) {
        return customerRepository.save(customer);
    }

    public void deleteById(String id) {
        customerRepository.deleteById(id);
    }
}
