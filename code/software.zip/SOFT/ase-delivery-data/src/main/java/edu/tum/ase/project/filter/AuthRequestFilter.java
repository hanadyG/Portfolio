package edu.tum.ase.project.filter;

import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import java.io.*;
import org.springframework.web.filter.OncePerRequestFilter;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import org.springframework.http.ResponseEntity;

@Component
public class AuthRequestFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {
        WebClient client = WebClient.create("http://ase-delivery-auth:8081");
        String jwt = null;
        String xsrf = null;
        String session = null;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                if (cookies[i].getName().equals("jwt")) {
                    jwt = cookies[i].getValue();
                }
                if (cookies[i].getName().equals("XSRF-TOKEN")) {
                    xsrf = cookies[i].getValue();
                }
                if (cookies[i].getName().equals("JSESSIONID")) {
                    session = cookies[i].getValue();
                }
            }
        }

        ResponseEntity<String> res = null;
        if(request.getRequestURI().contains("/tags"))  {
            filterChain.doFilter(request, response);
        }
        else if (jwt != null) {
            try {
                System.out.println("Method: " + request.getMethod());

                if (request.getMethod().equals("GET")) {
                    System.out.println("get");
                    System.out.println(request.getRequestURI());
                    res = client.get().uri(request.getRequestURI()).cookie("jwt", jwt).cookie("XSRF-TOKEN", xsrf)
                            .cookie("JSESSIONID", session).retrieve()
                            .onStatus(status -> status.value() == 401, clientResponse -> Mono.error(new Exception()))
                            .toEntity(String.class)
                            .block();
                } else {
                    System.out.println(request.getRequestURI());
                    String[] end = request.getRequestURI().split("/");
                    res = client.get().uri("/check/" + end[1]).cookie("jwt", jwt).cookie("XSRF-TOKEN", xsrf)
                            .cookie("JSESSIONID", session).retrieve()
                            .onStatus(status -> status.value() != 200,
                                    clientResponse -> Mono.error(new Exception()))
                            .toEntity(String.class)
                            .block();
                }
                System.out.println(res);
                filterChain.doFilter(request, response);
            } catch (Exception e) {
                System.out.println(e.getMessage());
                response.sendError(HttpStatus.UNAUTHORIZED.value());
            }

        } else {
            System.out.println("test");
            response.sendError(HttpStatus.BAD_REQUEST.value(),
                    "No JWT Token or Basic Auth Info Found");
        }

    }
}
